# Travel Backend MVP Design

## Goal

Build the MVP backend for the travel mini-program using Gin, GORM, and PostgreSQL. The backend supports account/password login now, keeps WeChat login fields and endpoint shape reserved, and exposes product browsing and admin product-management APIs.

## Scope

In scope:

- Gin HTTP server with versionless REST routes under `/api`.
- PostgreSQL connection through GORM.
- Auto migration for MVP tables.
- JWT authentication for user and admin sessions.
- User account registration and login.
- Reserved WeChat login endpoint and user table fields.
- Admin account login.
- Travel product create, edit, list, detail, and status update.
- Public product list/detail only returns published products for list; detail reports offline products as unavailable.
- Health check and environment-based configuration.

Out of scope:

- Real WeChat `code2Session` integration.
- Payments, orders, refunds, coupons, and marketing features.
- Multi-role admin permission system.
- File upload and object storage.
- Formal migration tooling.

## Architecture

The service is a small monolith with explicit internal packages:

- `cmd/server` owns process startup.
- `internal/config` reads environment variables.
- `internal/database` opens PostgreSQL and runs GORM auto migration.
- `internal/models` defines database entities.
- `internal/auth` owns password hashing and JWT creation/parsing.
- `internal/middleware` validates JWTs.
- `internal/handlers` owns request validation and API responses.
- `internal/router` wires routes and middleware.

This keeps the MVP easy to understand while leaving clean seams for orders, payments, uploads, and real WeChat login later.

## Authentication

User auth:

- `POST /api/auth/register` creates a user with `username`, `password`, and optional `nickname`.
- `POST /api/auth/login` verifies username/password and returns a JWT.
- `POST /api/auth/wechat-login` is reserved. For now it accepts `code` and returns `501 Not Implemented` unless mock mode is explicitly enabled later.

Admin auth:

- `POST /api/admin/login` verifies `admin_users.username` and `password_hash`.
- Admin-only APIs require JWT claims with subject type `admin`.

JWT claims include:

- subject ID
- subject type: `user` or `admin`
- expiry time

## Data Model

`users`:

- `id`
- `username`
- `password_hash`
- `openid`
- `unionid`
- `session_key`
- `nickname`
- `avatar_url`
- `created_at`
- `updated_at`
- `last_login_at`

`admin_users`:

- `id`
- `username`
- `password_hash`
- `created_at`
- `updated_at`
- `last_login_at`

`travel_products`:

- `id`
- `title`
- `cover_image`
- `banner_images`
- `short_description`
- `price`
- `sales_count`
- `tag`
- `summary`
- `itinerary`
- `fee_description`
- `travel_notice`
- `refund_policy`
- `customer_service_phone`
- `sort_order`
- `status`: `draft`, `published`, `offline`
- `created_at`
- `updated_at`

`banner_images` is stored as a string array through a GORM serializer, exposed as JSON array in API responses.

## API Behavior

Public/user routes:

- `GET /health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/wechat-login`
- `GET /api/products`
- `GET /api/products/:id`

Admin routes:

- `POST /api/admin/login`
- `GET /api/admin/products`
- `POST /api/admin/products`
- `PUT /api/admin/products/:id`
- `PATCH /api/admin/products/:id/status`

Validation:

- Required product fields: title, cover image, price, sales count, itinerary, fee description, travel notice, status.
- Price must be greater than or equal to 0.
- Sales count must be greater than or equal to 0.
- Status must be one of `draft`, `published`, `offline`.

## Error Handling

Responses use a consistent JSON shape:

```json
{
  "error": "human readable message"
}
```

Successful responses return resource-specific JSON directly, such as `{ "token": "...", "user": {...} }` or `{ "productList": [...], "total": 10 }`.

## Testing

The initial verification target is:

- `go test ./...`
- `go build ./cmd/server`

Unit tests cover password hashing, JWT validation, and product validation helpers. Handler integration tests can be added after the API stabilizes.
