# Travel Backend MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the Gin, GORM, PostgreSQL backend for the travel mini-program MVP with account/password auth and reserved WeChat login fields.

**Architecture:** Create a small Go monolith under `E:\code\travel\backend` with packages for config, database, models, auth, middleware, handlers, and routing. Use GORM AutoMigrate for MVP schema setup and JWT for user/admin authentication.

**Tech Stack:** Go, Gin, GORM, PostgreSQL driver, bcrypt, JWT, godotenv.

---

### Task 1: Initialize Go Project

**Files:**
- Create: `go.mod`
- Create: `.env.example`
- Create: `README.md`

- [ ] **Step 1: Initialize module**

Run:

```powershell
go mod init travel-backend
```

Expected: `go.mod` is created with module `travel-backend`.

- [ ] **Step 2: Add dependencies**

Run:

```powershell
go get github.com/gin-gonic/gin gorm.io/gorm gorm.io/driver/postgres github.com/joho/godotenv golang.org/x/crypto/bcrypt github.com/golang-jwt/jwt/v5 github.com/google/uuid
```

Expected: dependencies are added to `go.mod` and `go.sum`.

- [ ] **Step 3: Create `.env.example`**

```env
SERVER_ADDR=:8080
DATABASE_URL=host=localhost user=postgres password=postgres dbname=travel_mvp port=5432 sslmode=disable TimeZone=Asia/Shanghai
JWT_SECRET=change-me
JWT_EXPIRES_HOURS=168
ADMIN_SEED_USERNAME=admin
ADMIN_SEED_PASSWORD=admin123456
```

- [ ] **Step 4: Create README**

```markdown
# Travel Backend

Gin + GORM + PostgreSQL backend for the travel mini-program MVP.

## Setup

1. Copy `.env.example` to `.env`.
2. Update `DATABASE_URL` and `JWT_SECRET`.
3. Create the PostgreSQL database.
4. Run:

```powershell
go run ./cmd/server
```

The server runs on `SERVER_ADDR`, default `:8080`.
```

- [ ] **Step 5: Verify module**

Run:

```powershell
go mod tidy
```

Expected: command exits successfully.

### Task 2: Configuration, Database, and Models

**Files:**
- Create: `internal/config/config.go`
- Create: `internal/database/database.go`
- Create: `internal/models/user.go`
- Create: `internal/models/admin_user.go`
- Create: `internal/models/travel_product.go`

- [ ] **Step 1: Implement config**

Create `internal/config/config.go` with environment loading for `SERVER_ADDR`, `DATABASE_URL`, `JWT_SECRET`, `JWT_EXPIRES_HOURS`, `ADMIN_SEED_USERNAME`, and `ADMIN_SEED_PASSWORD`.

- [ ] **Step 2: Implement models**

Create GORM models:

```go
type User struct {
    ID           string `gorm:"type:uuid;primaryKey"`
    Username     string `gorm:"uniqueIndex;size:64"`
    PasswordHash string `gorm:"size:255"`
    OpenID       string `gorm:"uniqueIndex;size:128"`
    UnionID      string `gorm:"size:128"`
    SessionKey   string `gorm:"size:255"`
    Nickname     string `gorm:"size:64"`
    AvatarURL    string `gorm:"size:500"`
    CreatedAt    time.Time
    UpdatedAt    time.Time
    LastLoginAt  *time.Time
}
```

Use the same UUID string pattern for `AdminUser` and `TravelProduct`. `TravelProduct.BannerImages` should use `serializer:json` and expose `[]string`.

- [ ] **Step 3: Implement database connection**

Create `internal/database/database.go` with `Open(dsn string) (*gorm.DB, error)` and `AutoMigrate(db *gorm.DB) error`.

- [ ] **Step 4: Verify compile**

Run:

```powershell
go test ./...
```

Expected: packages compile.

### Task 3: Auth Utilities

**Files:**
- Create: `internal/auth/password.go`
- Create: `internal/auth/jwt.go`
- Create: `internal/auth/auth_test.go`

- [ ] **Step 1: Write tests**

Tests cover:

- Hashing a password and verifying the original password succeeds.
- Verifying a wrong password fails.
- Creating and parsing a JWT with subject type `user`.
- Rejecting a token signed with a different secret.

- [ ] **Step 2: Implement password helpers**

Functions:

```go
func HashPassword(password string) (string, error)
func CheckPassword(hash string, password string) bool
```

- [ ] **Step 3: Implement JWT helpers**

Functions:

```go
type SubjectType string
const SubjectUser SubjectType = "user"
const SubjectAdmin SubjectType = "admin"

type Claims struct {
    SubjectID   string      `json:"subjectId"`
    SubjectType SubjectType `json:"subjectType"`
    jwt.RegisteredClaims
}

func GenerateToken(subjectID string, subjectType SubjectType, secret string, ttl time.Duration) (string, error)
func ParseToken(tokenString string, secret string) (*Claims, error)
```

- [ ] **Step 4: Run tests**

Run:

```powershell
go test ./internal/auth -v
```

Expected: all auth tests pass.

### Task 4: Router, Middleware, and Server Startup

**Files:**
- Create: `cmd/server/main.go`
- Create: `internal/router/router.go`
- Create: `internal/middleware/auth.go`
- Create: `internal/handlers/response.go`

- [ ] **Step 1: Implement response helpers**

Create helpers:

```go
func Error(c *gin.Context, status int, message string)
func OK(c *gin.Context, payload gin.H)
```

- [ ] **Step 2: Implement auth middleware**

Middleware reads `Authorization: Bearer <token>`, parses JWT, verifies the expected subject type, and stores `subjectID` in Gin context.

- [ ] **Step 3: Implement router skeleton**

Add `GET /health` returning `{ "status": "ok" }`. Wire future route groups:

- `/api/auth`
- `/api/products`
- `/api/admin`

- [ ] **Step 4: Implement main**

Startup flow:

1. Load config.
2. Connect database.
3. Auto migrate.
4. Seed admin user when configured and absent.
5. Run Gin server.

- [ ] **Step 5: Verify build**

Run:

```powershell
go build ./cmd/server
```

Expected: build succeeds.

### Task 5: User and Admin Auth Handlers

**Files:**
- Create: `internal/handlers/auth_handler.go`
- Create: `internal/handlers/admin_auth_handler.go`
- Modify: `internal/router/router.go`

- [ ] **Step 1: Implement user register**

`POST /api/auth/register` accepts:

```json
{
  "username": "user1",
  "password": "password123",
  "nickname": "User One"
}
```

Validates username is non-empty and password length is at least 6. Creates user and returns token plus user object.

- [ ] **Step 2: Implement user login**

`POST /api/auth/login` accepts username/password, verifies credentials, updates `last_login_at`, and returns token plus user object.

- [ ] **Step 3: Implement reserved WeChat login**

`POST /api/auth/wechat-login` accepts `{ "code": "..." }` and returns HTTP 501 with message `wechat login is reserved but not implemented`.

- [ ] **Step 4: Implement admin login**

`POST /api/admin/login` accepts username/password, verifies admin credentials, updates `last_login_at`, and returns admin JWT.

- [ ] **Step 5: Wire routes**

Add public auth routes and admin login route to `internal/router/router.go`.

- [ ] **Step 6: Verify build**

Run:

```powershell
go test ./...
```

Expected: all packages compile and tests pass.

### Task 6: Product Handlers

**Files:**
- Create: `internal/handlers/product_handler.go`
- Modify: `internal/router/router.go`

- [ ] **Step 1: Implement product request/response DTOs**

DTOs include all PRD fields:

- title
- coverImage
- bannerImages
- shortDescription
- price
- salesCount
- tag
- summary
- itinerary
- feeDescription
- travelNotice
- refundPolicy
- customerServicePhone
- sortOrder
- status

- [ ] **Step 2: Implement public list**

`GET /api/products?page=1&pageSize=20` returns only `published` products ordered by `sort_order DESC, created_at DESC`.

- [ ] **Step 3: Implement public detail**

`GET /api/products/:id` returns product detail when published. If offline or draft, return `404` with `product is unavailable`.

- [ ] **Step 4: Implement admin list**

`GET /api/admin/products` supports `page`, `pageSize`, `keyword`, and returns all statuses.

- [ ] **Step 5: Implement admin create/update**

Validate required fields and numeric constraints, then create/update product.

- [ ] **Step 6: Implement admin status patch**

`PATCH /api/admin/products/:id/status` accepts:

```json
{
  "status": "published"
}
```

Status must be `draft`, `published`, or `offline`.

- [ ] **Step 7: Wire routes with middleware**

Admin product routes require admin JWT middleware.

- [ ] **Step 8: Verify build**

Run:

```powershell
go test ./...
```

Expected: all packages compile and tests pass.

### Task 7: Final Verification

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README API list**

Document all implemented endpoints and the default seeded admin account from `.env`.

- [ ] **Step 2: Format code**

Run:

```powershell
gofmt -w .
```

Expected: Go files are formatted.

- [ ] **Step 3: Tidy modules**

Run:

```powershell
go mod tidy
```

Expected: module files are clean.

- [ ] **Step 4: Run tests**

Run:

```powershell
go test ./...
```

Expected: all tests pass.

- [ ] **Step 5: Build server**

Run:

```powershell
go build ./cmd/server
```

Expected: server binary builds successfully.
