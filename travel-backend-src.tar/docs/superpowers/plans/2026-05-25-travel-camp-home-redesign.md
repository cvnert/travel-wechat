# Travel Camp Home Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rework the mini-program, admin UI, and backend into a cohesive camp-booking experience with a branded home page, manageable home content, and a shared home data API.

**Architecture:** Add a backend home aggregation endpoint that returns published products partitioned into hero and recommendation groups, derived from existing product fields. Update the mini-program home page to render that data in a visual layout inspired by the provided screenshots. Refresh the admin product editor and list styling so operators can maintain the cover, carousel, summary, tag, and sort order needed by the new home page.

**Tech Stack:** Go, Gin, GORM, PostgreSQL, WeChat Mini Program, React, Vite, Ant Design

---

### Task 1: Backend home aggregation

**Files:**
- Modify: `backend/internal/handlers/product_handler.go`
- Modify: `backend/internal/router/router.go`
- Test: `backend/internal/handlers/product_handler_test.go`
- Modify: `backend/internal/models/travel_product.go` only if a helper is required for home sorting

- [ ] **Step 1: Write the failing test**

```go
func TestHomePageReturnsHeroAndFeaturedProducts(t *testing.T) {
	// build a gin router with an in-memory sqlite/postgres test DB fixture
	// seed three published products with different sort orders and banner images
	// call GET /api/home and assert:
	// - response has heroBanners with at least the top product's banner images
	// - response has featuredProducts ordered by sort_order desc
	// - each featured product includes coverImageUrl and bannerImageUrls
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/handlers -run TestHomePageReturnsHeroAndFeaturedProducts -v`
Expected: FAIL because `/api/home` does not exist yet.

- [ ] **Step 3: Write minimal implementation**

```go
func (h ProductHandler) Home(c *gin.Context) {
	var products []models.TravelProduct
	query := h.DB.Model(&models.TravelProduct{}).Where("status = ?", models.ProductStatusPublished)
	if err := query.Order("sort_order DESC, created_at DESC").Limit(8).Find(&products).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to load home products")
		return
	}

	heroBanners := []string{}
	if len(products) > 0 {
		heroBanners = append(heroBanners, h.toProductResponse(c, products[0]).BannerImageURLs...)
		if len(heroBanners) == 0 {
			heroBanners = append(heroBanners, h.toProductResponse(c, products[0]).CoverImageURL)
		}
	}

	OK(c, gin.H{
		"heroBanners":      heroBanners,
		"featuredProducts":  h.toProductResponses(c, products),
		"sectionTitle":      "营地预定",
		"sectionSubtitle":   "精选线路、住宿和活动套餐",
	})
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/handlers -run TestHomePageReturnsHeroAndFeaturedProducts -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/internal/handlers/product_handler.go backend/internal/router/router.go backend/internal/handlers/product_handler_test.go backend/docs/superpowers/plans/2026-05-25-travel-camp-home-redesign.md
git commit -m "feat: add home aggregation api"
```

### Task 2: Mini-program home redesign

**Files:**
- Modify: `font/pages/home/index.js`
- Modify: `font/pages/home/index.wxml`
- Modify: `font/pages/home/index.wxss`
- Modify: `font/utils/api.js`
- Modify: `font/pages/home/index.json`

- [ ] **Step 1: Write the failing test**

```js
test('home api client normalizes home payload', async () => {
  // assert the client exposes getHomeContent() and maps the response shape
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `node --test font/tests/*.test.mjs`
Expected: FAIL because `getHomeContent` does not exist yet.

- [ ] **Step 3: Write minimal implementation**

```js
function getHomeContent() {
  return request({ url: '/api/home' })
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `node --test font/tests/*.test.mjs`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add font/pages/home/index.js font/pages/home/index.wxml font/pages/home/index.wxss font/utils/api.js font/pages/home/index.json
git commit -m "feat: redesign mini program home"
```

### Task 3: Admin content maintenance polish

**Files:**
- Modify: `admin/src/App.tsx`
- Modify: `admin/src/index.css`
- Modify: `admin/src/types.ts`
- Modify: `admin/src/api.ts` only if the backend home endpoint needs a client helper

- [ ] **Step 1: Write the failing test**

```ts
test('product payload supports home-facing fields', () => {
  // assert the type includes coverImage, bannerImages, shortDescription, tag, sortOrder, status
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npm run build`
Expected: FAIL if the new UI references missing fields or helpers.

- [ ] **Step 3: Write minimal implementation**

```ts
// keep existing product schema, but restyle list/editor with home-oriented labels
```

- [ ] **Step 4: Run test to verify it passes**

Run: `npm run build`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add admin/src/App.tsx admin/src/index.css admin/src/types.ts admin/src/api.ts
git commit -m "feat: polish admin for home content"
```
