package auth

import (
	"testing"
	"time"
)

func TestPasswordHashAndCheck(t *testing.T) {
	hash, err := HashPassword("secret123")
	if err != nil {
		t.Fatalf("HashPassword returned error: %v", err)
	}

	if !CheckPassword(hash, "secret123") {
		t.Fatal("expected password check to pass")
	}

	if CheckPassword(hash, "wrong") {
		t.Fatal("expected wrong password check to fail")
	}
}

func TestGenerateAndParseToken(t *testing.T) {
	token, err := GenerateToken("user-id", SubjectUser, "secret", time.Hour)
	if err != nil {
		t.Fatalf("GenerateToken returned error: %v", err)
	}

	claims, err := ParseToken(token, "secret")
	if err != nil {
		t.Fatalf("ParseToken returned error: %v", err)
	}

	if claims.SubjectID != "user-id" {
		t.Fatalf("expected subject id user-id, got %s", claims.SubjectID)
	}
	if claims.SubjectType != SubjectUser {
		t.Fatalf("expected subject type user, got %s", claims.SubjectType)
	}
}

func TestParseTokenRejectsWrongSecret(t *testing.T) {
	token, err := GenerateToken("user-id", SubjectUser, "secret", time.Hour)
	if err != nil {
		t.Fatalf("GenerateToken returned error: %v", err)
	}

	if _, err := ParseToken(token, "other-secret"); err == nil {
		t.Fatal("expected ParseToken to reject wrong secret")
	}
}
