package auth

import (
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type SubjectType string

const (
	SubjectUser  SubjectType = "user"
	SubjectAdmin SubjectType = "admin"
)

type Claims struct {
	SubjectID   string      `json:"subjectId"`
	SubjectType SubjectType `json:"subjectType"`
	jwt.RegisteredClaims
}

func GenerateToken(subjectID string, subjectType SubjectType, secret string, ttl time.Duration) (string, error) {
	now := time.Now()
	claims := Claims{
		SubjectID:   subjectID,
		SubjectType: subjectType,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
			Subject:   subjectID,
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(secret))
}

func ParseToken(tokenString string, secret string) (*Claims, error) {
	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	if !token.Valid {
		return nil, jwt.ErrTokenInvalidClaims
	}
	return claims, nil
}
