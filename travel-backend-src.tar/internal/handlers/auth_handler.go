package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"hash/crc32"
	"net/http"
	"net/url"
	"strings"
	"time"
	"travel-backend/internal/auth"
	"travel-backend/internal/middleware"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type AuthHandler struct {
	DB               *gorm.DB
	JWTSecret        string
	JWTExpires       time.Duration
	WechatMiniAppID  string
	WechatMiniSecret string
	WechatClient     WechatSessionClient
	Uploader         storage.Uploader
}

type registerRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Nickname string `json:"nickname"`
}

type loginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type wechatLoginRequest struct {
	Code    string        `json:"code"`
	Profile wechatProfile `json:"profile"`
}

type wechatProfile struct {
	NickName  string `json:"nickName"`
	AvatarURL string `json:"avatarUrl"`
	Gender    int    `json:"gender"`
	Country   string `json:"country"`
	Province  string `json:"province"`
	City      string `json:"city"`
	Language  string `json:"language"`
}

type WechatSessionClient interface {
	Code2Session(ctx context.Context, appID string, secret string, code string) (wechatSession, error)
}

type wechatSession struct {
	OpenID     string `json:"openid"`
	UnionID    string `json:"unionid"`
	SessionKey string `json:"session_key"`
	ErrCode    int    `json:"errcode"`
	ErrMsg     string `json:"errmsg"`
}

type httpWechatSessionClient struct {
	HTTPClient *http.Client
}

func (h AuthHandler) Register(c *gin.Context) {
	var req registerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}

	req.Username = strings.TrimSpace(req.Username)
	if req.Username == "" || len(req.Password) < 6 {
		Error(c, http.StatusBadRequest, "username is required and password must be at least 6 characters")
		return
	}

	passwordHash, err := auth.HashPassword(req.Password)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to hash password")
		return
	}

	user := models.User{
		ID:           uuid.NewString(),
		Username:     req.Username,
		PasswordHash: passwordHash,
		Nickname:     strings.TrimSpace(req.Nickname),
	}
	if err := h.DB.Create(&user).Error; err != nil {
		Error(c, http.StatusConflict, "username already exists")
		return
	}

	token, err := auth.GenerateToken(user.ID, auth.SubjectUser, h.JWTSecret, h.JWTExpires)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to generate token")
		return
	}

	OK(c, gin.H{"token": token, "user": user})
}

func (h AuthHandler) Login(c *gin.Context) {
	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}

	var user models.User
	err := h.DB.Where("username = ?", strings.TrimSpace(req.Username)).First(&user).Error
	if errors.Is(err, gorm.ErrRecordNotFound) || !auth.CheckPassword(user.PasswordHash, req.Password) {
		Error(c, http.StatusUnauthorized, "invalid username or password")
		return
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query user")
		return
	}

	now := time.Now()
	user.LastLoginAt = &now
	_ = h.DB.Save(&user).Error

	token, err := auth.GenerateToken(user.ID, auth.SubjectUser, h.JWTSecret, h.JWTExpires)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to generate token")
		return
	}

	OK(c, gin.H{"token": token, "user": user})
}

func (h AuthHandler) WechatLogin(c *gin.Context) {
	var req wechatLoginRequest
	if err := c.ShouldBindJSON(&req); err != nil || strings.TrimSpace(req.Code) == "" {
		Error(c, http.StatusBadRequest, "code is required")
		return
	}

	if strings.TrimSpace(h.WechatMiniAppID) == "" || strings.TrimSpace(h.WechatMiniSecret) == "" {
		Error(c, http.StatusInternalServerError, "wechat mini program is not configured")
		return
	}

	client := h.WechatClient
	if client == nil {
		client = httpWechatSessionClient{HTTPClient: http.DefaultClient}
	}
	session, err := client.Code2Session(c.Request.Context(), h.WechatMiniAppID, h.WechatMiniSecret, strings.TrimSpace(req.Code))
	if err != nil {
		Error(c, http.StatusBadGateway, "failed to exchange wechat code")
		return
	}
	if session.ErrCode != 0 {
		Error(c, http.StatusUnauthorized, firstNonEmpty(session.ErrMsg, "wechat code is invalid"))
		return
	}
	if strings.TrimSpace(session.OpenID) == "" {
		Error(c, http.StatusBadGateway, "wechat did not return openid")
		return
	}

	user, err := h.findOrCreateWechatUser(session, req.Profile)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to save wechat user")
		return
	}

	token, err := auth.GenerateToken(user.ID, auth.SubjectUser, h.JWTSecret, h.JWTExpires)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to generate token")
		return
	}

	responseUser, err := h.presentUser(c.Request.Context(), user)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to build wechat user response")
		return
	}

	response := gin.H{"token": token, "user": responseUser}
	fmt.Printf("wechat login response: %+v\n", response)
	OK(c, response)
}

func (h AuthHandler) UpdateWechatProfile(c *gin.Context) {
	subjectID, ok := c.Get(middleware.SubjectIDKey)
	if !ok {
		Error(c, http.StatusUnauthorized, "missing user identity")
		return
	}
	userID, ok := subjectID.(string)
	if !ok || strings.TrimSpace(userID) == "" {
		Error(c, http.StatusUnauthorized, "invalid user identity")
		return
	}

	var req struct {
		Profile wechatProfile `json:"profile"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}

	var user models.User
	if err := h.DB.Where("id = ?", userID).First(&user).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "user not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query user")
		return
	}

	applyWechatProfile(&user, req.Profile)
	if err := h.DB.Save(&user).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to save wechat profile")
		return
	}

	responseUser, err := h.presentUser(c.Request.Context(), user)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to build wechat profile response")
		return
	}

	response := gin.H{"user": responseUser}
	fmt.Printf("wechat profile response: %+v\n", response)
	OK(c, response)
}

func (h AuthHandler) presentUser(ctx context.Context, user models.User) (models.User, error) {
	avatarURL, err := resolveStoredUploadURL(ctx, h.Uploader, user.AvatarURL)
	if err != nil {
		return models.User{}, err
	}

	user.AvatarURL = avatarURL
	return user, nil
}

func (h AuthHandler) findOrCreateWechatUser(session wechatSession, profile wechatProfile) (models.User, error) {
	var user models.User
	err := h.DB.Where(wechatOpenIDColumn()+" = ?", strings.TrimSpace(session.OpenID)).First(&user).Error
	now := time.Now()
	if err == nil {
		user.UnionID = strings.TrimSpace(session.UnionID)
		user.SessionKey = strings.TrimSpace(session.SessionKey)
		applyWechatProfile(&user, profile)
		ensureWechatNickname(&user)
		user.LastLoginAt = &now
		return user, h.DB.Save(&user).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return user, err
	}

	user = models.User{
		ID:          uuid.NewString(),
		Username:    "wx_" + strings.TrimSpace(session.OpenID),
		OpenID:      strings.TrimSpace(session.OpenID),
		UnionID:     strings.TrimSpace(session.UnionID),
		SessionKey:  strings.TrimSpace(session.SessionKey),
		LastLoginAt: &now,
	}
	applyWechatProfile(&user, profile)
	ensureWechatNickname(&user)
	return user, h.DB.Create(&user).Error
}

func wechatOpenIDColumn() string {
	return "open_id"
}

func applyWechatProfile(user *models.User, profile wechatProfile) {
	if strings.TrimSpace(profile.NickName) != "" {
		user.Nickname = strings.TrimSpace(profile.NickName)
	}
	if strings.TrimSpace(profile.AvatarURL) != "" {
		user.AvatarURL = strings.TrimSpace(profile.AvatarURL)
	}
	user.Gender = profile.Gender
	user.Country = strings.TrimSpace(profile.Country)
	user.Province = strings.TrimSpace(profile.Province)
	user.City = strings.TrimSpace(profile.City)
	user.Language = strings.TrimSpace(profile.Language)
}

func ensureWechatNickname(user *models.User) {
	if strings.TrimSpace(user.Nickname) != "" {
		user.Nickname = strings.TrimSpace(user.Nickname)
		return
	}

	checksum := crc32.ChecksumIEEE([]byte(strings.TrimSpace(user.OpenID)))
	user.Nickname = buildDefaultWechatNickname(int(checksum), int(checksum>>8))
}

func buildDefaultWechatNickname(adjectiveIndex int, fruitIndex int) string {
	adjectives := []string{
		"飞翔",
		"奔跑",
		"发光",
		"快乐",
		"勇敢",
		"自在",
		"闪耀",
		"温暖",
	}
	fruits := []string{
		"橘子",
		"菠萝",
		"桃子",
		"西瓜",
		"柠檬",
		"葡萄",
		"芒果",
		"草莓",
	}

	if adjectiveIndex < 0 {
		adjectiveIndex = -adjectiveIndex
	}
	if fruitIndex < 0 {
		fruitIndex = -fruitIndex
	}
	return adjectives[adjectiveIndex%len(adjectives)] + "的" + fruits[fruitIndex%len(fruits)]
}

func (c httpWechatSessionClient) Code2Session(ctx context.Context, appID string, secret string, code string) (wechatSession, error) {
	httpClient := c.HTTPClient
	if httpClient == nil {
		httpClient = http.DefaultClient
	}

	values := url.Values{}
	values.Set("appid", appID)
	values.Set("secret", secret)
	values.Set("js_code", code)
	values.Set("grant_type", "authorization_code")

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.weixin.qq.com/sns/jscode2session?"+values.Encode(), nil)
	if err != nil {
		return wechatSession{}, err
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		return wechatSession{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return wechatSession{}, fmt.Errorf("wechat status %d", resp.StatusCode)
	}

	var session wechatSession
	if err := json.NewDecoder(resp.Body).Decode(&session); err != nil {
		return wechatSession{}, err
	}
	return session, nil
}
