package handlers

import (
	"testing"
	"time"
)

func TestValidateUploadFileAcceptsSupportedImages(t *testing.T) {
	tests := []string{"cover.jpg", "cover.jpeg", "cover.png", "cover.webp", "COVER.PNG"}

	for _, name := range tests {
		if err := validateUploadFile(name, 1024); err != nil {
			t.Fatalf("expected %s to be accepted, got %v", name, err)
		}
	}
}

func TestValidateUploadFileRejectsUnsupportedExtension(t *testing.T) {
	if err := validateUploadFile("cover.gif", 1024); err == nil {
		t.Fatal("expected gif upload to be rejected")
	}
}

func TestValidateUploadFileRejectsOversizedFile(t *testing.T) {
	if err := validateUploadFile("cover.png", maxUploadSize+1); err == nil {
		t.Fatal("expected oversized upload to be rejected")
	}
}

func TestBuildUploadObjectKeyUsesPrefixDateAndID(t *testing.T) {
	now := time.Date(2026, 5, 25, 10, 30, 0, 0, time.UTC)

	got := buildUploadObjectKey("travel/", "Cover.PNG", now, "fixed-id")
	want := "travel/20260525/fixed-id.png"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}

func TestBuildUploadObjectKeyDefaultsToUploadsPrefix(t *testing.T) {
	now := time.Date(2026, 5, 25, 10, 30, 0, 0, time.UTC)

	got := buildUploadObjectKey("", "cover.jpg", now, "fixed-id")
	want := "uploads/20260525/fixed-id.jpg"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}

func TestAvatarUploadPrefixAppendsAvatarsToConfiguredPrefix(t *testing.T) {
	got := avatarUploadPrefix("travel/")
	want := "travel/avatars"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}

func TestAvatarUploadPrefixDefaultsWhenPrefixIsEmpty(t *testing.T) {
	got := avatarUploadPrefix("")
	want := "avatars"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}
