package handlers

import (
	"testing"
	"travel-backend/internal/models"
)

func TestApplyHomeBannerRequestLeavesBlankLinkedProductIDNil(t *testing.T) {
	banner := applyHomeBannerRequest(models.HomeBanner{}, homeBannerRequest{
		Title:           "Hero",
		Image:           "hero.jpg",
		LinkedProductID: "   ",
		Status:          models.BannerStatusDraft,
	})

	if banner.LinkedProductID != nil {
		t.Fatalf("expected blank linked product id to be nil, got %v", *banner.LinkedProductID)
	}
}

func TestApplyHomeBannerRequestStoresLinkedProductIDWhenProvided(t *testing.T) {
	id := "11111111-1111-1111-1111-111111111111"
	banner := applyHomeBannerRequest(models.HomeBanner{}, homeBannerRequest{
		Title:           "Hero",
		Image:           "hero.jpg",
		LinkedProductID: id,
		Status:          models.BannerStatusDraft,
	})

	if banner.LinkedProductID == nil {
		t.Fatal("expected linked product id to be set")
	}
	if *banner.LinkedProductID != id {
		t.Fatalf("expected linked product id %s, got %s", id, *banner.LinkedProductID)
	}
}
