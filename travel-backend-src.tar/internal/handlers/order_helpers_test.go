package handlers

import (
	"strings"
	"testing"
	"time"
	"travel-backend/internal/models"
)

func TestBuildOrderNumberUsesTimestampAndUserSuffix(t *testing.T) {
	now := time.Date(2026, 5, 30, 14, 15, 16, 0, time.UTC)

	got := buildOrderNumber(now, "user-123456")

	if !strings.HasPrefix(got, "TR20260530141516") {
		t.Fatalf("expected timestamp prefix, got %s", got)
	}
	if !strings.HasSuffix(got, "3456") {
		t.Fatalf("expected user suffix 3456, got %s", got)
	}
}

func TestSummarizeOrderItemsCalculatesTotalAmountAndQuantity(t *testing.T) {
	items := []models.TravelOrderItem{
		{Quantity: 2, SubtotalAmount: 199.8},
		{Quantity: 1, SubtotalAmount: 88},
	}

	amount, quantity := summarizeOrderItems(items)

	if amount != 287.8 {
		t.Fatalf("expected total amount 287.8, got %v", amount)
	}
	if quantity != 3 {
		t.Fatalf("expected total quantity 3, got %d", quantity)
	}
}

func TestBuildOrderItemsCopiesProductSnapshotAndSubtotal(t *testing.T) {
	cartItems := []models.TravelCartItem{
		{
			ProductID: "product-1",
			Quantity:  3,
			Product: models.TravelProduct{
				Title:      "云南小团",
				CoverImage: "travel/products/yunnan.png",
				Price:      299.5,
			},
		},
	}

	items := buildOrderItems("order-1", cartItems)

	if len(items) != 1 {
		t.Fatalf("expected 1 order item, got %d", len(items))
	}
	if items[0].ProductTitle != "云南小团" {
		t.Fatalf("expected product title snapshot, got %s", items[0].ProductTitle)
	}
	if items[0].SubtotalAmount != 898.5 {
		t.Fatalf("expected subtotal 898.5, got %v", items[0].SubtotalAmount)
	}
}

func TestValidOrderStatusRecognizesSupportedValues(t *testing.T) {
	if !models.ValidOrderStatus(models.OrderStatusPendingPayment) {
		t.Fatal("expected pending_payment to be valid")
	}
	if !models.ValidOrderStatus("pending_travel") {
		t.Fatal("expected pending_travel to be valid")
	}
	if !models.ValidOrderStatus("completed") {
		t.Fatal("expected completed to be valid")
	}
	if !models.ValidOrderStatus("paid") {
		t.Fatal("expected paid legacy alias to be valid")
	}
	if models.ValidOrderStatus("cancelled") {
		t.Fatal("expected cancelled to be invalid")
	}
}
