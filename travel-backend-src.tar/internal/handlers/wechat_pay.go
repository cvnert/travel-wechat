package handlers

import (
	"context"
	"crypto"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"travel-backend/internal/models"
)

const (
	wechatPayJSAPIURL = "https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi"
	wechatPaySignType = "RSA"
)

type WechatPayService struct {
	AppID                  string
	MerchantID             string
	PublicKeyID            string
	PublicKeyPath          string
	APIv3Key               string
	MerchantPrivateKeyPath string
	MerchantCertSerialNo   string
	NotifyURL              string
	HTTPClient             *http.Client
}

type WechatMiniProgramPaymentParams struct {
	TimeStamp string `json:"timeStamp"`
	NonceStr  string `json:"nonceStr"`
	Package   string `json:"package"`
	SignType  string `json:"signType"`
	PaySign   string `json:"paySign"`
}

type WechatPayNotification struct {
	AppID         string
	MerchantID    string
	OutTradeNo    string
	TransactionID string
	TradeState    string
	TotalFee      int
	PayerTotalFee int
	SuccessTime   time.Time
}

type wechatPayCreateOrderRequest struct {
	AppID       string              `json:"appid"`
	MerchantID  string              `json:"mchid"`
	Description string              `json:"description"`
	OutTradeNo  string              `json:"out_trade_no"`
	NotifyURL   string              `json:"notify_url"`
	Amount      wechatPayAmount     `json:"amount"`
	Payer       wechatPayJSAPIPayer `json:"payer"`
}

type wechatPayAmount struct {
	Total    int    `json:"total"`
	Currency string `json:"currency"`
}

type wechatPayJSAPIPayer struct {
	OpenID string `json:"openid"`
}

type wechatPayCreateOrderResponse struct {
	PrepayID string `json:"prepay_id"`
}

type wechatPayAPIError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

type wechatPayNotifyEnvelope struct {
	EventType string                `json:"event_type"`
	Resource  wechatPayNotifyCipher `json:"resource"`
}

type wechatPayNotifyCipher struct {
	Algorithm      string `json:"algorithm"`
	Ciphertext     string `json:"ciphertext"`
	AssociatedData string `json:"associated_data"`
	Nonce          string `json:"nonce"`
}

type wechatPayTransactionPayload struct {
	AppID         string `json:"appid"`
	MerchantID    string `json:"mchid"`
	OutTradeNo    string `json:"out_trade_no"`
	TransactionID string `json:"transaction_id"`
	TradeState    string `json:"trade_state"`
	SuccessTime   string `json:"success_time"`
	Amount        struct {
		Total      int    `json:"total"`
		PayerTotal int    `json:"payer_total"`
		Currency   string `json:"currency"`
	} `json:"amount"`
}

func (s *WechatPayService) Configured() bool {
	return s != nil &&
		strings.TrimSpace(s.AppID) != "" &&
		strings.TrimSpace(s.MerchantID) != "" &&
		strings.TrimSpace(s.PublicKeyID) != "" &&
		strings.TrimSpace(s.PublicKeyPath) != "" &&
		strings.TrimSpace(s.APIv3Key) != "" &&
		strings.TrimSpace(s.MerchantPrivateKeyPath) != "" &&
		strings.TrimSpace(s.MerchantCertSerialNo) != "" &&
		strings.TrimSpace(s.NotifyURL) != ""
}

func (s *WechatPayService) CreateMiniProgramPayment(ctx context.Context, order models.TravelOrder, openID string) (WechatMiniProgramPaymentParams, error) {
	if !s.Configured() {
		return WechatMiniProgramPaymentParams{}, errors.New("wechat pay is not configured")
	}
	if strings.TrimSpace(openID) == "" {
		return WechatMiniProgramPaymentParams{}, errors.New("missing wechat openid")
	}

	requestBody := wechatPayCreateOrderRequest{
		AppID:       s.AppID,
		MerchantID:  s.MerchantID,
		Description: buildWechatPayDescription(order),
		OutTradeNo:  order.OrderNo,
		NotifyURL:   s.NotifyURL,
		Amount: wechatPayAmount{
			Total:    amountToFen(order.TotalAmount),
			Currency: "CNY",
		},
		Payer: wechatPayJSAPIPayer{OpenID: strings.TrimSpace(openID)},
	}

	body, err := json.Marshal(requestBody)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	privateKey, err := s.loadMerchantPrivateKey()
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	timestamp := strconv.FormatInt(time.Now().Unix(), 10)
	nonceStr, err := randomWechatPayString(32)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	authorization, err := s.buildAuthorization(privateKey, http.MethodPost, "/v3/pay/transactions/jsapi", timestamp, nonceStr, string(body))
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, wechatPayJSAPIURL, strings.NewReader(string(body)))
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}
	req.Header.Set("Authorization", authorization)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "travel-backend/1.0")
	if strings.TrimSpace(s.PublicKeyID) != "" {
		req.Header.Set("Wechatpay-Serial", strings.TrimSpace(s.PublicKeyID))
	}

	resp, err := s.httpClient().Do(req)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	if err := s.verifyResponseSignature(resp.Header, responseBody, false); err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return WechatMiniProgramPaymentParams{}, parseWechatPayAPIError(responseBody, resp.StatusCode)
	}

	var createResponse wechatPayCreateOrderResponse
	if err := json.Unmarshal(responseBody, &createResponse); err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}
	if strings.TrimSpace(createResponse.PrepayID) == "" {
		return WechatMiniProgramPaymentParams{}, errors.New("wechat pay did not return prepay_id")
	}

	return s.buildMiniProgramPaymentParams(privateKey, createResponse.PrepayID)
}

func (s *WechatPayService) ParsePaymentNotification(headers http.Header, body []byte) (WechatPayNotification, error) {
	if !s.Configured() {
		return WechatPayNotification{}, errors.New("wechat pay is not configured")
	}

	if err := s.verifyResponseSignature(headers, body, true); err != nil {
		return WechatPayNotification{}, err
	}

	var envelope wechatPayNotifyEnvelope
	if err := json.Unmarshal(body, &envelope); err != nil {
		return WechatPayNotification{}, err
	}
	if strings.TrimSpace(envelope.EventType) != "TRANSACTION.SUCCESS" {
		return WechatPayNotification{}, fmt.Errorf("unsupported wechat pay event %q", envelope.EventType)
	}

	plaintext, err := s.decryptNotificationResource(envelope.Resource)
	if err != nil {
		return WechatPayNotification{}, err
	}

	var payload wechatPayTransactionPayload
	if err := json.Unmarshal(plaintext, &payload); err != nil {
		return WechatPayNotification{}, err
	}

	successTime, err := time.Parse(time.RFC3339, strings.TrimSpace(payload.SuccessTime))
	if err != nil {
		return WechatPayNotification{}, err
	}

	return WechatPayNotification{
		AppID:         strings.TrimSpace(payload.AppID),
		MerchantID:    strings.TrimSpace(payload.MerchantID),
		OutTradeNo:    strings.TrimSpace(payload.OutTradeNo),
		TransactionID: strings.TrimSpace(payload.TransactionID),
		TradeState:    strings.TrimSpace(payload.TradeState),
		TotalFee:      payload.Amount.Total,
		PayerTotalFee: payload.Amount.PayerTotal,
		SuccessTime:   successTime,
	}, nil
}

func (s *WechatPayService) buildMiniProgramPaymentParams(privateKey *rsa.PrivateKey, prepayID string) (WechatMiniProgramPaymentParams, error) {
	timeStamp := strconv.FormatInt(time.Now().Unix(), 10)
	nonceStr, err := randomWechatPayString(32)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}
	pkg := "prepay_id=" + strings.TrimSpace(prepayID)
	message := strings.Join([]string{
		s.AppID,
		timeStamp,
		nonceStr,
		pkg,
		"",
	}, "\n")

	signature, err := signWechatPayMessage(privateKey, message)
	if err != nil {
		return WechatMiniProgramPaymentParams{}, err
	}

	return WechatMiniProgramPaymentParams{
		TimeStamp: timeStamp,
		NonceStr:  nonceStr,
		Package:   pkg,
		SignType:  wechatPaySignType,
		PaySign:   signature,
	}, nil
}

func (s *WechatPayService) buildAuthorization(privateKey *rsa.PrivateKey, method string, canonicalURL string, timestamp string, nonceStr string, body string) (string, error) {
	message := strings.Join([]string{
		method,
		canonicalURL,
		timestamp,
		nonceStr,
		body,
		"",
	}, "\n")

	signature, err := signWechatPayMessage(privateKey, message)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf(
		`WECHATPAY2-SHA256-RSA2048 mchid="%s",nonce_str="%s",timestamp="%s",serial_no="%s",signature="%s"`,
		s.MerchantID,
		nonceStr,
		timestamp,
		s.MerchantCertSerialNo,
		signature,
	), nil
}

func (s *WechatPayService) verifyResponseSignature(headers http.Header, body []byte, strict bool) error {
	publicKey, err := s.loadWechatPayPublicKey()
	if err != nil {
		if strict {
			return err
		}
		return nil
	}

	timestamp := strings.TrimSpace(headers.Get("Wechatpay-Timestamp"))
	nonce := strings.TrimSpace(headers.Get("Wechatpay-Nonce"))
	signature := strings.TrimSpace(headers.Get("Wechatpay-Signature"))
	serial := strings.TrimSpace(headers.Get("Wechatpay-Serial"))

	if timestamp == "" || nonce == "" || signature == "" || serial == "" {
		if strict {
			return errors.New("missing wechat pay signature headers")
		}
		return nil
	}

	if strings.TrimSpace(s.PublicKeyID) != "" && serial != strings.TrimSpace(s.PublicKeyID) {
		return fmt.Errorf("unexpected wechat pay serial %q", serial)
	}

	if strict {
		parsedTimestamp, err := strconv.ParseInt(timestamp, 10, 64)
		if err != nil {
			return err
		}
		if math.Abs(float64(time.Now().Unix()-parsedTimestamp)) > 5*60 {
			return errors.New("wechat pay notification timestamp has expired")
		}
	}

	message := timestamp + "\n" + nonce + "\n" + string(body) + "\n"
	return verifyWechatPaySignature(publicKey, message, signature)
}

func (s *WechatPayService) decryptNotificationResource(resource wechatPayNotifyCipher) ([]byte, error) {
	if strings.TrimSpace(resource.Algorithm) != "AEAD_AES_256_GCM" {
		return nil, fmt.Errorf("unsupported notification algorithm %q", resource.Algorithm)
	}
	if len(strings.TrimSpace(s.APIv3Key)) != 32 {
		return nil, errors.New("invalid api v3 key length")
	}

	ciphertext, err := base64.StdEncoding.DecodeString(strings.TrimSpace(resource.Ciphertext))
	if err != nil {
		return nil, err
	}

	block, err := aes.NewCipher([]byte(strings.TrimSpace(s.APIv3Key)))
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	return gcm.Open(
		nil,
		[]byte(resource.Nonce),
		ciphertext,
		[]byte(resource.AssociatedData),
	)
}

func (s *WechatPayService) httpClient() *http.Client {
	if s != nil && s.HTTPClient != nil {
		return s.HTTPClient
	}
	return &http.Client{Timeout: 15 * time.Second}
}

func (s *WechatPayService) loadMerchantPrivateKey() (*rsa.PrivateKey, error) {
	content, err := os.ReadFile(strings.TrimSpace(s.MerchantPrivateKeyPath))
	if err != nil {
		return nil, err
	}

	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode merchant private key pem")
	}

	if key, err := x509.ParsePKCS1PrivateKey(block.Bytes); err == nil {
		return key, nil
	}

	key, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	privateKey, ok := key.(*rsa.PrivateKey)
	if !ok {
		return nil, errors.New("merchant private key is not rsa")
	}
	return privateKey, nil
}

func (s *WechatPayService) loadWechatPayPublicKey() (*rsa.PublicKey, error) {
	if strings.TrimSpace(s.PublicKeyPath) == "" {
		return nil, errors.New("missing wechat pay public key path")
	}

	content, err := os.ReadFile(strings.TrimSpace(s.PublicKeyPath))
	if err != nil {
		return nil, err
	}

	block, _ := pem.Decode(content)
	if block == nil {
		return nil, errors.New("failed to decode wechat pay public key pem")
	}

	switch block.Type {
	case "PUBLIC KEY":
		publicKeyValue, err := x509.ParsePKIXPublicKey(block.Bytes)
		if err != nil {
			return nil, err
		}
		publicKey, ok := publicKeyValue.(*rsa.PublicKey)
		if !ok {
			return nil, errors.New("wechat pay public key is not rsa")
		}
		return publicKey, nil
	case "CERTIFICATE":
		certificate, err := x509.ParseCertificate(block.Bytes)
		if err != nil {
			return nil, err
		}
		publicKey, ok := certificate.PublicKey.(*rsa.PublicKey)
		if !ok {
			return nil, errors.New("wechat pay certificate public key is not rsa")
		}
		return publicKey, nil
	default:
		return nil, fmt.Errorf("unsupported wechat pay public key pem type %q", block.Type)
	}
}

func buildWechatPayDescription(order models.TravelOrder) string {
	if len(order.Items) == 0 {
		return "旅游订单 " + strings.TrimSpace(order.OrderNo)
	}

	firstTitle := strings.TrimSpace(order.Items[0].ProductTitle)
	if len(order.Items) == 1 {
		return truncateWechatPayDescription(firstTitle)
	}
	return truncateWechatPayDescription(fmt.Sprintf("%s 等%d件商品", firstTitle, len(order.Items)))
}

func truncateWechatPayDescription(value string) string {
	runes := []rune(strings.TrimSpace(value))
	if len(runes) == 0 {
		return "旅游订单"
	}
	if len(runes) <= 64 {
		return string(runes)
	}
	return string(runes[:64])
}

func amountToFen(amount float64) int {
	return int(math.Round(amount * 100))
}

func randomWechatPayString(length int) (string, error) {
	if length <= 0 {
		return "", nil
	}

	const alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	buffer := make([]byte, length)
	randomBytes := make([]byte, length)
	if _, err := rand.Read(randomBytes); err != nil {
		return "", err
	}

	for i := range buffer {
		buffer[i] = alphabet[int(randomBytes[i])%len(alphabet)]
	}
	return string(buffer), nil
}

func signWechatPayMessage(privateKey *rsa.PrivateKey, message string) (string, error) {
	digest := sha256.Sum256([]byte(message))
	signature, err := rsa.SignPKCS1v15(rand.Reader, privateKey, crypto.SHA256, digest[:])
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(signature), nil
}

func verifyWechatPaySignature(publicKey *rsa.PublicKey, message string, signature string) error {
	signatureBytes, err := base64.StdEncoding.DecodeString(strings.TrimSpace(signature))
	if err != nil {
		return err
	}

	digest := sha256.Sum256([]byte(message))
	return rsa.VerifyPKCS1v15(publicKey, crypto.SHA256, digest[:], signatureBytes)
}

func parseWechatPayAPIError(body []byte, statusCode int) error {
	var payload wechatPayAPIError
	if err := json.Unmarshal(body, &payload); err == nil {
		if strings.TrimSpace(payload.Message) != "" {
			if strings.TrimSpace(payload.Code) != "" {
				return fmt.Errorf("wechat pay api error (%s): %s", payload.Code, payload.Message)
			}
			return fmt.Errorf("wechat pay api error: %s", payload.Message)
		}
	}

	bodyText := strings.TrimSpace(string(body))
	if bodyText == "" {
		return fmt.Errorf("wechat pay api error: http %d", statusCode)
	}
	return fmt.Errorf("wechat pay api error: %s", bodyText)
}
