package handlers

import (
	"errors"
	"net/http"
	"strings"
	"time"
	"travel-backend/internal/auth"
	"travel-backend/internal/models"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type AdminAuthHandler struct {
	DB         *gorm.DB
	JWTSecret  string
	JWTExpires time.Duration
}

func (h AdminAuthHandler) Login(c *gin.Context) {
	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}

	var admin models.AdminUser
	err := h.DB.Where("username = ?", strings.TrimSpace(req.Username)).First(&admin).Error
	if errors.Is(err, gorm.ErrRecordNotFound) || !auth.CheckPassword(admin.PasswordHash, req.Password) {
		Error(c, http.StatusUnauthorized, "invalid username or password")
		return
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query admin")
		return
	}

	now := time.Now()
	admin.LastLoginAt = &now
	_ = h.DB.Save(&admin).Error

	token, err := auth.GenerateToken(admin.ID, auth.SubjectAdmin, h.JWTSecret, h.JWTExpires)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to generate token")
		return
	}

	OK(c, gin.H{"token": token, "admin": admin})
}
