package handlers

import (
	"testing"
	"time"
	"travel-backend/internal/models"
)

func TestBuildHomeContentUsesTopProductBannersAndFeaturedProducts(t *testing.T) {
	products := []productResponse{
		{
			TravelProduct: models.TravelProduct{
				ID:               "top",
				Title:            "Northwest Route",
				CoverImage:       "top-cover.jpg",
				ShortDescription: "Stay above the valley",
				Summary:          "Quiet tent suites in the forest",
				Tag:              "Featured",
				Price:            3200,
				SortOrder:        20,
				CreatedAt:        time.Date(2026, 5, 25, 8, 0, 0, 0, time.UTC),
			},
			CoverImageURL:   "https://cdn.example.com/top-cover.jpg",
			BannerImageURLs: []string{"https://cdn.example.com/top-1.jpg", "https://cdn.example.com/top-2.jpg"},
		},
		{
			TravelProduct: models.TravelProduct{
				ID:               "second",
				Title:            "Valley Tent Hotel",
				CoverImage:       "second-cover.jpg",
				ShortDescription: "Travel beside the old trail",
				Price:            1980,
				SortOrder:        10,
			},
			CoverImageURL: "https://cdn.example.com/second-cover.jpg",
		},
	}

	got := buildHomeContent(products, nil)

	if len(got.HeroBanners) != 2 {
		t.Fatalf("expected two hero banners, got %d", len(got.HeroBanners))
	}
	if got.HeroBanners[0].ImageURL != "https://cdn.example.com/top-1.jpg" {
		t.Fatalf("expected first hero banner to use top banner image, got %s", got.HeroBanners[0].ImageURL)
	}
	if got.HeroBanners[0].Title != "Northwest Route" {
		t.Fatalf("expected hero title from top product, got %s", got.HeroBanners[0].Title)
	}
	if len(got.FeaturedProducts) != 2 {
		t.Fatalf("expected two featured products, got %d", len(got.FeaturedProducts))
	}
	if got.FeaturedProducts[0].ID != "top" {
		t.Fatalf("expected first featured product to be top product, got %s", got.FeaturedProducts[0].ID)
	}
	if got.SectionTitle != "线路预订" {
		t.Fatalf("expected section title 线路预订, got %s", got.SectionTitle)
	}
}

func TestBuildHomeContentFallsBackToCoverImageForHero(t *testing.T) {
	products := []productResponse{
		{
			TravelProduct: models.TravelProduct{
				ID:         "cover-only",
				Title:      "Forest Cabin",
				CoverImage: "cover.jpg",
			},
			CoverImageURL: "https://cdn.example.com/cover.jpg",
		},
	}

	got := buildHomeContent(products, nil)

	if len(got.HeroBanners) != 1 {
		t.Fatalf("expected one hero banner, got %d", len(got.HeroBanners))
	}
	if got.HeroBanners[0].ImageURL != "https://cdn.example.com/cover.jpg" {
		t.Fatalf("expected hero to fall back to cover image, got %s", got.HeroBanners[0].ImageURL)
	}
}

func TestBuildHomeContentPrefersManagedBanners(t *testing.T) {
	products := []productResponse{
		{
			TravelProduct: models.TravelProduct{
				ID:    "product",
				Title: "Product Banner",
			},
			CoverImageURL: "https://cdn.example.com/product.jpg",
		},
	}
	banners := []homeBannerResponse{
		{
			ProductID:   "linked",
			Title:       "Managed Banner",
			Description: "A curated home page image",
			ImageURL:    "https://cdn.example.com/managed.jpg",
			Tag:         "Hero",
		},
	}

	got := buildHomeContent(products, banners)

	if len(got.HeroBanners) != 1 {
		t.Fatalf("expected one managed hero banner, got %d", len(got.HeroBanners))
	}
	if got.HeroBanners[0].Title != "Managed Banner" {
		t.Fatalf("expected managed banner title, got %s", got.HeroBanners[0].Title)
	}
	if got.HeroBanners[0].ImageURL != "https://cdn.example.com/managed.jpg" {
		t.Fatalf("expected managed banner image, got %s", got.HeroBanners[0].ImageURL)
	}
}
