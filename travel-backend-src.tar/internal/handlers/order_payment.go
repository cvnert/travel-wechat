package handlers

import (
	"errors"
	"io"
	"net/http"
	"strings"
	"time"

	"travel-backend/internal/models"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

func (h OrderHandler) PayOrder(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}
	if h.WechatPay == nil || !h.WechatPay.Configured() {
		Error(c, http.StatusInternalServerError, "wechat pay is not configured")
		return
	}

	order, ok := h.findOrderForUser(c, userID, c.Param("id"))
	if !ok {
		return
	}

	if order.PaymentStatus == models.PaymentStatusPaid {
		if err := h.syncPaidOrderStateForUser(userID, &order); err != nil {
			Error(c, http.StatusInternalServerError, "failed to load paid order")
			return
		}
		OK(c, gin.H{"order": h.toOrderResponse(c, order)})
		return
	}

	if models.NormalizeOrderStatus(order.Status) != models.OrderStatusPendingPayment {
		Error(c, http.StatusBadRequest, "order is not payable")
		return
	}

	if strings.TrimSpace(order.User.OpenID) == "" {
		Error(c, http.StatusBadRequest, "missing wechat openid")
		return
	}

	if strings.TrimSpace(order.PaymentMethod) != models.PaymentMethodWechatPay {
		if err := h.DB.Model(&models.TravelOrder{}).
			Where("id = ? AND user_id = ?", order.ID, userID).
			Update("payment_method", models.PaymentMethodWechatPay).Error; err != nil {
			Error(c, http.StatusInternalServerError, "failed to prepare order payment method")
			return
		}
		order.PaymentMethod = models.PaymentMethodWechatPay
	}

	paymentParams, err := h.WechatPay.CreateMiniProgramPayment(c.Request.Context(), order, order.User.OpenID)
	if err != nil {
		Error(c, http.StatusBadGateway, err.Error())
		return
	}

	OK(c, gin.H{
		"order":         h.toOrderResponse(c, order),
		"paymentParams": paymentParams,
	})
}

func (h OrderHandler) WechatPayNotify(c *gin.Context) {
	if h.WechatPay == nil || !h.WechatPay.Configured() {
		c.JSON(http.StatusInternalServerError, gin.H{"code": "FAIL", "message": "wechat pay is not configured"})
		return
	}

	body, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": "FAIL", "message": "failed to read request body"})
		return
	}

	notification, err := h.WechatPay.ParsePaymentNotification(c.Request.Header, body)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": "FAIL", "message": err.Error()})
		return
	}

	if notification.AppID != strings.TrimSpace(h.WechatPay.AppID) || notification.MerchantID != strings.TrimSpace(h.WechatPay.MerchantID) {
		c.JSON(http.StatusBadRequest, gin.H{"code": "FAIL", "message": "notification appid or mchid mismatch"})
		return
	}

	if strings.TrimSpace(notification.TradeState) != "SUCCESS" {
		c.JSON(http.StatusOK, gin.H{"code": "SUCCESS", "message": "ignored"})
		return
	}

	if err := h.DB.Transaction(func(tx *gorm.DB) error {
		var order models.TravelOrder
		if err := tx.
			Clauses(clause.Locking{Strength: "UPDATE"}).
			Preload("Items").
			Preload("User").
			Where("order_no = ?", notification.OutTradeNo).
			First(&order).Error; err != nil {
			return err
		}

		if amountToFen(order.TotalAmount) != notification.TotalFee {
			return errors.New("wechat pay amount mismatch")
		}

		if order.PaymentStatus == models.PaymentStatusPaid {
			return nil
		}

		return h.completeOrderPayment(tx, &order, models.PaymentMethodWechatPay, notification.TransactionID, notification.SuccessTime)
	}); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": "FAIL", "message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"code": "SUCCESS", "message": "OK"})
}

func (h OrderHandler) completeOrderPayment(tx *gorm.DB, order *models.TravelOrder, paymentMethod string, transactionID string, paidAt time.Time) error {
	if order == nil {
		return errors.New("missing order")
	}
	if paidAt.IsZero() {
		paidAt = time.Now()
	}
	if order.PaymentStatus == models.PaymentStatusPaid {
		return nil
	}

	verificationCode := models.BuildVerificationCode(order.ID, paidAt)
	updates := map[string]any{
		"status":            models.OrderStatusPendingTravel,
		"payment_status":    models.PaymentStatusPaid,
		"payment_method":    paymentMethod,
		"verification_code": verificationCode,
		"paid_at":           &paidAt,
	}
	if strings.TrimSpace(transactionID) != "" {
		updates["wechat_transaction_id"] = strings.TrimSpace(transactionID)
	}

	if err := tx.Model(&models.TravelOrder{}).
		Where("id = ?", order.ID).
		Updates(updates).Error; err != nil {
		return err
	}

	for _, item := range order.Items {
		if err := tx.Model(&models.TravelProduct{}).
			Where("id = ?", item.ProductID).
			UpdateColumn("sales_count", gorm.Expr("sales_count + ?", item.Quantity)).Error; err != nil {
			return err
		}
	}

	order.Status = models.OrderStatusPendingTravel
	order.PaymentStatus = models.PaymentStatusPaid
	order.PaymentMethod = paymentMethod
	order.VerificationCode = verificationCode
	order.PaidAt = &paidAt
	order.WechatTransactionID = strings.TrimSpace(transactionID)
	return nil
}
