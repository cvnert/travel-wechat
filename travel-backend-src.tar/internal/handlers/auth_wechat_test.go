package handlers

import (
	"context"
	"io"
	"strings"
	"testing"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"
)

func TestWechatOpenIDColumnUsesModelFieldName(t *testing.T) {
	if got := wechatOpenIDColumn(); got != "open_id" {
		t.Fatalf("expected open_id column name, got %s", got)
	}
}

func TestApplyWechatProfileStoresProfileFields(t *testing.T) {
	user := models.User{}

	applyWechatProfile(&user, wechatProfile{
		NickName:  "  旅人  ",
		AvatarURL: "  https://example.com/avatar.png  ",
		Gender:    2,
		Country:   "  China  ",
		Province:  "  Guangdong  ",
		City:      "  Shenzhen  ",
		Language:  "  zh_CN  ",
	})

	if user.Nickname != "旅人" {
		t.Fatalf("expected nickname to be trimmed and stored, got %q", user.Nickname)
	}
	if user.AvatarURL != "https://example.com/avatar.png" {
		t.Fatalf("expected avatar url to be trimmed and stored, got %q", user.AvatarURL)
	}
	if user.Gender != 2 {
		t.Fatalf("expected gender 2, got %d", user.Gender)
	}
	if user.Country != "China" || user.Province != "Guangdong" || user.City != "Shenzhen" || user.Language != "zh_CN" {
		t.Fatalf("expected location/language fields to be stored, got %#v", user)
	}
}

func TestDefaultWechatNicknameUsesPlayfulFruitName(t *testing.T) {
	nickname := buildDefaultWechatNickname(0, 0)

	if nickname != "飞翔的橘子" {
		t.Fatalf("expected playful default nickname, got %q", nickname)
	}
}

func TestEnsureWechatNicknameFillsEmptyNickname(t *testing.T) {
	user := models.User{OpenID: "openid-123"}

	ensureWechatNickname(&user)

	if !strings.Contains(user.Nickname, "的") {
		t.Fatalf("expected generated nickname to contain 的, got %q", user.Nickname)
	}
	if user.Nickname == "" || strings.Contains(user.Nickname, "openid") {
		t.Fatalf("expected generated nickname instead of openid, got %q", user.Nickname)
	}
}

type testPublicURLUploader struct {
	url string
}

func (u testPublicURLUploader) Upload(ctx context.Context, objectKey string, reader io.Reader) (storage.UploadResult, error) {
	panic("unexpected call")
}

func (u testPublicURLUploader) SignedURL(ctx context.Context, objectKey string) (string, error) {
	panic("unexpected call")
}

func (u testPublicURLUploader) PublicURL(ctx context.Context, objectKey string) (string, error) {
	return u.url, nil
}

func TestPresentUserResolvesStoredAvatarKeyToPublicURL(t *testing.T) {
	handler := AuthHandler{
		Uploader: testPublicURLUploader{url: "https://cdn.example.com/travel/avatars/20260530/avatar.png"},
	}

	user, err := handler.presentUser(context.Background(), models.User{
		AvatarURL: "travel/avatars/20260530/avatar.png",
	})
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if user.AvatarURL != "https://cdn.example.com/travel/avatars/20260530/avatar.png" {
		t.Fatalf("expected public avatar url, got %q", user.AvatarURL)
	}
}
