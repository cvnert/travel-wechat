package handlers

import (
	"errors"
	"math"
	"net/http"
	"strconv"
	"strings"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type ProductHandler struct {
	DB       *gorm.DB
	Uploader storage.Uploader
}

type productRequest struct {
	Title                string   `json:"title"`
	CoverImage           string   `json:"coverImage"`
	BannerImages         []string `json:"bannerImages"`
	DetailImages         []string `json:"detailImages"`
	ShortDescription     string   `json:"shortDescription"`
	Price                float64  `json:"price"`
	SalesCount           int      `json:"salesCount"`
	Tag                  string   `json:"tag"`
	Summary              string   `json:"summary"`
	Itinerary            string   `json:"itinerary"`
	FeeDescription       string   `json:"feeDescription"`
	TravelNotice         string   `json:"travelNotice"`
	RefundPolicy         string   `json:"refundPolicy"`
	CustomerServicePhone string   `json:"customerServicePhone"`
	SortOrder            int      `json:"sortOrder"`
	Status               string   `json:"status"`
}

type statusRequest struct {
	Status string `json:"status"`
}

func (h ProductHandler) PublicList(c *gin.Context) {
	page, pageSize := pagination(c)
	var products []models.TravelProduct
	var total int64

	query := h.DB.Model(&models.TravelProduct{}).Where("status = ?", models.ProductStatusPublished)
	if err := query.Count(&total).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to count products")
		return
	}

	if err := query.Order("sort_order DESC, created_at DESC").Offset((page - 1) * pageSize).Limit(pageSize).Find(&products).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to list products")
		return
	}

	OK(c, gin.H{"productList": h.toProductResponses(c, products), "total": total})
}

func (h ProductHandler) PublicHome(c *gin.Context) {
	var products []models.TravelProduct
	var banners []models.HomeBanner

	if err := h.DB.Model(&models.TravelProduct{}).
		Where("status = ?", models.ProductStatusPublished).
		Order("sort_order DESC, created_at DESC").
		Limit(12).
		Find(&products).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to load home content")
		return
	}

	if err := h.DB.Model(&models.HomeBanner{}).
		Where("status = ?", models.BannerStatusPublished).
		Order("sort_order DESC, created_at DESC").
		Limit(6).
		Find(&banners).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to load home banners")
		return
	}

	OK(c, gin.H{"home": buildHomeContent(h.toProductResponses(c, products), h.toHomeBannerResponses(c, banners))})
}

func (h ProductHandler) PublicDetail(c *gin.Context) {
	product, ok := h.findProduct(c)
	if !ok {
		return
	}
	if product.Status != models.ProductStatusPublished {
		Error(c, http.StatusNotFound, "product is unavailable")
		return
	}

	OK(c, gin.H{"productDetail": h.toProductResponse(c, product)})
}

func (h ProductHandler) AdminList(c *gin.Context) {
	page, pageSize := pagination(c)
	keyword := strings.TrimSpace(c.Query("keyword"))
	var products []models.TravelProduct
	var total int64

	query := h.DB.Model(&models.TravelProduct{})
	if keyword != "" {
		query = query.Where("title ILIKE ?", "%"+keyword+"%")
	}

	if err := query.Count(&total).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to count products")
		return
	}

	if err := query.Order("sort_order DESC, created_at DESC").Offset((page - 1) * pageSize).Limit(pageSize).Find(&products).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to list products")
		return
	}

	OK(c, gin.H{"productList": h.toProductResponses(c, products), "total": total})
}

func (h ProductHandler) AdminDetail(c *gin.Context) {
	product, ok := h.findProduct(c)
	if !ok {
		return
	}

	OK(c, gin.H{"productDetail": h.toProductResponse(c, product)})
}

func (h ProductHandler) Create(c *gin.Context) {
	var req productRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if msg := validateProduct(req); msg != "" {
		Error(c, http.StatusBadRequest, msg)
		return
	}

	product := applyProductRequest(models.TravelProduct{ID: uuid.NewString()}, req)
	if err := h.DB.Create(&product).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to create product")
		return
	}

	OK(c, gin.H{"product": h.toProductResponse(c, product)})
}

func (h ProductHandler) Update(c *gin.Context) {
	product, ok := h.findProduct(c)
	if !ok {
		return
	}

	var req productRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if msg := validateProduct(req); msg != "" {
		Error(c, http.StatusBadRequest, msg)
		return
	}

	updated := applyProductRequest(product, req)
	if err := h.DB.Save(&updated).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to update product")
		return
	}

	OK(c, gin.H{"product": h.toProductResponse(c, updated)})
}

func (h ProductHandler) UpdateStatus(c *gin.Context) {
	product, ok := h.findProduct(c)
	if !ok {
		return
	}

	var req statusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if !models.ValidProductStatus(req.Status) {
		Error(c, http.StatusBadRequest, "invalid product status")
		return
	}

	product.Status = req.Status
	if err := h.DB.Save(&product).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to update product status")
		return
	}

	OK(c, gin.H{"product": h.toProductResponse(c, product)})
}

func (h ProductHandler) findProduct(c *gin.Context) (models.TravelProduct, bool) {
	var product models.TravelProduct
	err := h.DB.First(&product, "id = ?", c.Param("id")).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		Error(c, http.StatusNotFound, "product not found")
		return product, false
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query product")
		return product, false
	}
	return product, true
}

func validateProduct(req productRequest) string {
	if strings.TrimSpace(req.Title) == "" {
		return "title is required"
	}
	if strings.TrimSpace(req.CoverImage) == "" {
		return "coverImage is required"
	}
	if req.Price < 0 || math.IsNaN(req.Price) || math.IsInf(req.Price, 0) {
		return "price must be greater than or equal to 0"
	}
	if req.SalesCount < 0 {
		return "salesCount must be greater than or equal to 0"
	}
	if strings.TrimSpace(req.Itinerary) == "" {
		return "itinerary is required"
	}
	if strings.TrimSpace(req.FeeDescription) == "" {
		return "feeDescription is required"
	}
	if strings.TrimSpace(req.TravelNotice) == "" {
		return "travelNotice is required"
	}
	if !models.ValidProductStatus(req.Status) {
		return "invalid product status"
	}
	return ""
}

func applyProductRequest(product models.TravelProduct, req productRequest) models.TravelProduct {
	product.Title = strings.TrimSpace(req.Title)
	product.CoverImage = strings.TrimSpace(req.CoverImage)
	product.BannerImages = req.BannerImages
	product.DetailImages = req.DetailImages
	product.ShortDescription = strings.TrimSpace(req.ShortDescription)
	product.Price = req.Price
	product.SalesCount = req.SalesCount
	product.Tag = strings.TrimSpace(req.Tag)
	product.Summary = req.Summary
	product.Itinerary = req.Itinerary
	product.FeeDescription = req.FeeDescription
	product.TravelNotice = req.TravelNotice
	product.RefundPolicy = req.RefundPolicy
	product.CustomerServicePhone = strings.TrimSpace(req.CustomerServicePhone)
	product.SortOrder = req.SortOrder
	product.Status = req.Status
	return product
}

func pagination(c *gin.Context) (int, int) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}
	return page, pageSize
}

type productResponse struct {
	models.TravelProduct
	CoverImageURL   string   `json:"coverImageUrl"`
	BannerImageURLs []string `json:"bannerImageUrls"`
	DetailImageURLs []string `json:"detailImageUrls"`
}

type homeBannerResponse struct {
	ProductID   string `json:"productId"`
	Title       string `json:"title"`
	Description string `json:"description"`
	ImageURL    string `json:"imageUrl"`
	Tag         string `json:"tag"`
}

type homeContentResponse struct {
	Location         string                 `json:"location"`
	BrandName        string                 `json:"brandName"`
	SectionTitle     string                 `json:"sectionTitle"`
	SectionSubtitle  string                 `json:"sectionSubtitle"`
	HeroBanners      []homeBannerResponse   `json:"heroBanners"`
	FeaturedProducts []productResponse      `json:"featuredProducts"`
	QuickCategories  []homeCategoryResponse `json:"quickCategories"`
}

type homeCategoryResponse struct {
	Label string `json:"label"`
	Key   string `json:"key"`
}

func buildHomeContent(products []productResponse, banners []homeBannerResponse) homeContentResponse {
	content := homeContentResponse{
		Location:         "滇西北",
		BrandName:        "旅邦旅游",
		SectionTitle:     "线路预订",
		SectionSubtitle:  "精选旅行线路、活动套餐与周边服务",
		FeaturedProducts: products,
		QuickCategories: []homeCategoryResponse{
			{Label: "线路预订", Key: "route"},
			{Label: "活动套餐", Key: "package"},
			{Label: "周边服务", Key: "nearby"},
		},
	}

	if len(banners) > 0 {
		content.HeroBanners = banners
		return content
	}

	if len(products) == 0 {
		return content
	}

	topProduct := products[0]
	images := topProduct.BannerImageURLs
	if len(images) == 0 && topProduct.CoverImageURL != "" {
		images = []string{topProduct.CoverImageURL}
	}
	for _, imageURL := range images {
		if imageURL == "" {
			continue
		}
		content.HeroBanners = append(content.HeroBanners, homeBannerResponse{
			ProductID:   topProduct.ID,
			Title:       topProduct.Title,
			Description: firstNonEmpty(topProduct.ShortDescription, topProduct.Summary, "精选目的地旅行体验"),
			ImageURL:    imageURL,
			Tag:         topProduct.Tag,
		})
	}

	return content
}

func (h ProductHandler) toHomeBannerResponses(c *gin.Context, banners []models.HomeBanner) []homeBannerResponse {
	responses := make([]homeBannerResponse, 0, len(banners))
	for _, banner := range banners {
		productID := ""
		if banner.LinkedProductID != nil {
			productID = *banner.LinkedProductID
		}
		responses = append(responses, homeBannerResponse{
			ProductID:   productID,
			Title:       banner.Title,
			Description: banner.Description,
			ImageURL:    signImageKey(c, h.Uploader, banner.Image),
			Tag:         banner.Tag,
		})
	}
	return responses
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" {
			return value
		}
	}
	return ""
}

func (h ProductHandler) toProductResponses(c *gin.Context, products []models.TravelProduct) []productResponse {
	responses := make([]productResponse, 0, len(products))
	for _, product := range products {
		responses = append(responses, h.toProductResponse(c, product))
	}
	return responses
}

func (h ProductHandler) toProductResponse(c *gin.Context, product models.TravelProduct) productResponse {
	response := productResponse{TravelProduct: product}
	response.CoverImageURL = signImageKey(c, h.Uploader, product.CoverImage)
	for _, key := range product.BannerImages {
		response.BannerImageURLs = append(response.BannerImageURLs, signImageKey(c, h.Uploader, key))
	}
	for _, key := range product.DetailImages {
		response.DetailImageURLs = append(response.DetailImageURLs, signImageKey(c, h.Uploader, key))
	}
	return response
}

func signImageKey(c *gin.Context, uploader storage.Uploader, key string) string {
	key = strings.TrimSpace(key)
	if key == "" || isHTTPURL(key) {
		return key
	}
	url, err := uploader.SignedURL(c.Request.Context(), key)
	if err != nil {
		return ""
	}
	return url
}
