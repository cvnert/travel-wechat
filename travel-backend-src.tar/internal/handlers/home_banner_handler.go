package handlers

import (
	"errors"
	"net/http"
	"strings"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type HomeBannerHandler struct {
	DB       *gorm.DB
	Uploader storage.Uploader
}

type homeBannerRequest struct {
	Title           string `json:"title"`
	Description     string `json:"description"`
	Image           string `json:"image"`
	LinkedProductID string `json:"linkedProductId"`
	Tag             string `json:"tag"`
	SortOrder       int    `json:"sortOrder"`
	Status          string `json:"status"`
}

func (h HomeBannerHandler) AdminList(c *gin.Context) {
	var banners []models.HomeBanner
	if err := h.DB.Order("sort_order DESC, created_at DESC").Find(&banners).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to list home banners")
		return
	}
	OK(c, gin.H{"bannerList": h.toBannerResponses(c, banners)})
}

func (h HomeBannerHandler) AdminDetail(c *gin.Context) {
	banner, ok := h.findBanner(c)
	if !ok {
		return
	}
	OK(c, gin.H{"banner": h.toBannerResponse(c, banner)})
}

func (h HomeBannerHandler) Create(c *gin.Context) {
	var req homeBannerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if msg := validateHomeBanner(req); msg != "" {
		Error(c, http.StatusBadRequest, msg)
		return
	}

	banner := applyHomeBannerRequest(models.HomeBanner{ID: uuid.NewString()}, req)
	if err := h.DB.Create(&banner).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to create home banner")
		return
	}
	OK(c, gin.H{"banner": h.toBannerResponse(c, banner)})
}

func (h HomeBannerHandler) Update(c *gin.Context) {
	banner, ok := h.findBanner(c)
	if !ok {
		return
	}

	var req homeBannerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if msg := validateHomeBanner(req); msg != "" {
		Error(c, http.StatusBadRequest, msg)
		return
	}

	updated := applyHomeBannerRequest(banner, req)
	if err := h.DB.Save(&updated).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to update home banner")
		return
	}
	OK(c, gin.H{"banner": h.toBannerResponse(c, updated)})
}

func (h HomeBannerHandler) UpdateStatus(c *gin.Context) {
	banner, ok := h.findBanner(c)
	if !ok {
		return
	}

	var req statusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if !models.ValidBannerStatus(req.Status) {
		Error(c, http.StatusBadRequest, "invalid banner status")
		return
	}

	banner.Status = req.Status
	if err := h.DB.Save(&banner).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to update banner status")
		return
	}
	OK(c, gin.H{"banner": h.toBannerResponse(c, banner)})
}

func (h HomeBannerHandler) findBanner(c *gin.Context) (models.HomeBanner, bool) {
	var banner models.HomeBanner
	err := h.DB.First(&banner, "id = ?", c.Param("id")).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		Error(c, http.StatusNotFound, "home banner not found")
		return banner, false
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query home banner")
		return banner, false
	}
	return banner, true
}

func validateHomeBanner(req homeBannerRequest) string {
	if strings.TrimSpace(req.Title) == "" {
		return "title is required"
	}
	if strings.TrimSpace(req.Image) == "" {
		return "image is required"
	}
	if !models.ValidBannerStatus(req.Status) {
		return "invalid banner status"
	}
	return ""
}

func applyHomeBannerRequest(banner models.HomeBanner, req homeBannerRequest) models.HomeBanner {
	banner.Title = strings.TrimSpace(req.Title)
	banner.Description = strings.TrimSpace(req.Description)
	banner.Image = strings.TrimSpace(req.Image)
	linkedProductID := strings.TrimSpace(req.LinkedProductID)
	if linkedProductID == "" {
		banner.LinkedProductID = nil
	} else {
		banner.LinkedProductID = &linkedProductID
	}
	banner.Tag = strings.TrimSpace(req.Tag)
	banner.SortOrder = req.SortOrder
	banner.Status = req.Status
	return banner
}

type adminHomeBannerResponse struct {
	models.HomeBanner
	LinkedProductID string `json:"linkedProductId"`
	ImageURL        string `json:"imageUrl"`
}

func (h HomeBannerHandler) toBannerResponses(c *gin.Context, banners []models.HomeBanner) []adminHomeBannerResponse {
	responses := make([]adminHomeBannerResponse, 0, len(banners))
	for _, banner := range banners {
		responses = append(responses, h.toBannerResponse(c, banner))
	}
	return responses
}

func (h HomeBannerHandler) toBannerResponse(c *gin.Context, banner models.HomeBanner) adminHomeBannerResponse {
	response := adminHomeBannerResponse{HomeBanner: banner}
	if banner.LinkedProductID != nil {
		response.LinkedProductID = *banner.LinkedProductID
	}
	response.ImageURL = signImageKey(c, h.Uploader, banner.Image)
	return response
}
