package handlers

import (
	"context"
	"errors"
	"log"
	"net/http"
	"path"
	"path/filepath"
	"strings"
	"time"
	"travel-backend/internal/middleware"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

const maxUploadSize int64 = 5 << 20

type UploadHandler struct {
	Uploader storage.Uploader
	Prefix   string
	DB       *gorm.DB
}

type signUploadRequest struct {
	Keys []string `json:"keys"`
}

func (h UploadHandler) UploadImage(c *gin.Context) {
	result, err := h.uploadImage(c, h.Prefix)
	if err != nil {
		return
	}

	OK(c, gin.H{"key": result.Key, "url": result.URL})
}

func (h UploadHandler) UploadUserAvatar(c *gin.Context) {
	subjectID, ok := c.Get(middleware.SubjectIDKey)
	if !ok {
		Error(c, http.StatusUnauthorized, "missing user identity")
		return
	}
	userID, ok := subjectID.(string)
	if !ok || strings.TrimSpace(userID) == "" {
		Error(c, http.StatusUnauthorized, "invalid user identity")
		return
	}
	if h.DB == nil {
		Error(c, http.StatusInternalServerError, "upload handler database is not configured")
		return
	}

	var user models.User
	if err := h.DB.Where("id = ?", userID).First(&user).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "user not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query user")
		return
	}

	result, err := h.uploadImage(c, avatarUploadPrefix(h.Prefix))
	if err != nil {
		return
	}

	user.AvatarURL = result.Key
	if err := h.DB.Save(&user).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to save user avatar")
		return
	}

	avatarURL, err := resolveStoredUploadURL(c.Request.Context(), h.Uploader, user.AvatarURL)
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to build user avatar url")
		return
	}
	user.AvatarURL = avatarURL

	OK(c, gin.H{"key": result.Key, "url": avatarURL, "user": user})
}

func (h UploadHandler) uploadImage(c *gin.Context, prefix string) (storage.UploadResult, error) {
	file, err := c.FormFile("file")
	if err != nil {
		Error(c, http.StatusBadRequest, "file is required")
		return storage.UploadResult{}, err
	}

	if err := validateUploadFile(file.Filename, file.Size); err != nil {
		Error(c, http.StatusBadRequest, err.Error())
		return storage.UploadResult{}, err
	}

	src, err := file.Open()
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to open uploaded file")
		return storage.UploadResult{}, err
	}
	defer src.Close()

	objectKey := buildUploadObjectKey(prefix, file.Filename, time.Now(), uuid.NewString())
	result, err := h.Uploader.Upload(c.Request.Context(), objectKey, src)
	if err != nil {
		log.Printf("upload image failed: key=%s filename=%s size=%d error=%v", objectKey, file.Filename, file.Size, err)
		Error(c, http.StatusInternalServerError, "failed to upload file")
		return storage.UploadResult{}, err
	}

	return result, nil
}

func (h UploadHandler) SignImages(c *gin.Context) {
	var req signUploadRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if len(req.Keys) > 100 {
		Error(c, http.StatusBadRequest, "too many keys")
		return
	}

	urls := make(map[string]string, len(req.Keys))
	for _, key := range req.Keys {
		key = strings.TrimSpace(key)
		if key == "" {
			continue
		}
		if isHTTPURL(key) {
			urls[key] = key
			continue
		}
		url, err := h.Uploader.SignedURL(c.Request.Context(), key)
		if err != nil {
			Error(c, http.StatusInternalServerError, "failed to sign image url")
			return
		}
		urls[key] = url
	}

	OK(c, gin.H{"urls": urls})
}

func validateUploadFile(filename string, size int64) error {
	ext := strings.ToLower(filepath.Ext(filename))
	switch ext {
	case ".jpg", ".jpeg", ".png", ".webp":
	default:
		return errors.New("only jpg, jpeg, png and webp images are allowed")
	}

	if size > maxUploadSize {
		return errors.New("file size must be less than or equal to 5MB")
	}
	return nil
}

func buildUploadObjectKey(prefix string, filename string, now time.Time, id string) string {
	cleanPrefix := strings.Trim(path.Clean(prefix), "/")
	if cleanPrefix == "." || cleanPrefix == "" {
		cleanPrefix = "uploads"
	}

	ext := strings.ToLower(filepath.Ext(filename))
	return path.Join(cleanPrefix, now.Format("20060102"), id+ext)
}

func isHTTPURL(value string) bool {
	return strings.HasPrefix(strings.ToLower(value), "http://") || strings.HasPrefix(strings.ToLower(value), "https://")
}

func resolveStoredUploadURL(ctx context.Context, uploader storage.Uploader, value string) (string, error) {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" || isHTTPURL(trimmed) || strings.HasPrefix(trimmed, "/uploads/") {
		return trimmed, nil
	}
	if uploader == nil {
		return trimmed, nil
	}
	return uploader.PublicURL(ctx, trimmed)
}

func avatarUploadPrefix(prefix string) string {
	cleanPrefix := strings.Trim(path.Clean(prefix), "/")
	if cleanPrefix == "." || cleanPrefix == "" {
		return "avatars"
	}
	return path.Join(cleanPrefix, "avatars")
}
