package handlers

import (
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
	"travel-backend/internal/middleware"
	"travel-backend/internal/models"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type OrderHandler struct {
	DB        *gorm.DB
	Uploader  storage.Uploader
	WechatPay *WechatPayService
}

type cartItemRequest struct {
	ProductID string `json:"productId"`
	Quantity  int    `json:"quantity"`
}

type updateCartItemRequest struct {
	Quantity int `json:"quantity"`
}

type createOrderRequest struct {
	CartItemIDs []string `json:"cartItemIds"`
}

type verifyOrderRequest struct {
	VerificationCode string `json:"verificationCode"`
}

type cartResponse struct {
	CartItems       []cartItemResponse `json:"cartItems"`
	TotalQuantity   int                `json:"totalQuantity"`
	TotalAmount     float64            `json:"totalAmount"`
	SelectedItemIDs []string           `json:"selectedItemIds,omitempty"`
}

type cartItemResponse struct {
	ID             string          `json:"id"`
	ProductID      string          `json:"productId"`
	Quantity       int             `json:"quantity"`
	SubtotalAmount float64         `json:"subtotalAmount"`
	Product        productResponse `json:"product"`
	CreatedAt      time.Time       `json:"createdAt"`
	UpdatedAt      time.Time       `json:"updatedAt"`
}

type orderItemResponse struct {
	models.TravelOrderItem
	ProductCoverImageURL string `json:"productCoverImageUrl"`
}

type orderUserResponse struct {
	ID        string `json:"id"`
	Username  string `json:"username"`
	Nickname  string `json:"nickname"`
	AvatarURL string `json:"avatarUrl"`
}

type orderResponse struct {
	models.TravelOrder
	Items         []orderItemResponse `json:"items"`
	TotalQuantity int                 `json:"totalQuantity"`
	User          orderUserResponse   `json:"user"`
}

func (h OrderHandler) ListCart(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	var cartItems []models.TravelCartItem
	if err := h.DB.Preload("Product").Where("user_id = ?", userID).Order("created_at DESC").Find(&cartItems).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to load cart")
		return
	}

	OK(c, h.toCartPayload(c, cartItems))
}

func (h OrderHandler) AddCartItem(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	var req cartItemRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if strings.TrimSpace(req.ProductID) == "" {
		Error(c, http.StatusBadRequest, "productId is required")
		return
	}
	if req.Quantity < 1 {
		Error(c, http.StatusBadRequest, "quantity must be greater than 0")
		return
	}

	var product models.TravelProduct
	if err := h.DB.First(&product, "id = ?", strings.TrimSpace(req.ProductID)).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "product not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query product")
		return
	}
	if product.Status != models.ProductStatusPublished {
		Error(c, http.StatusBadRequest, "product is unavailable")
		return
	}

	var item models.TravelCartItem
	err := h.DB.Where("user_id = ? AND product_id = ?", userID, product.ID).First(&item).Error
	switch {
	case err == nil:
		item.Quantity += req.Quantity
		if err := h.DB.Save(&item).Error; err != nil {
			Error(c, http.StatusInternalServerError, "failed to update cart item")
			return
		}
	case errors.Is(err, gorm.ErrRecordNotFound):
		item = models.TravelCartItem{
			ID:        uuid.NewString(),
			UserID:    userID,
			ProductID: product.ID,
			Quantity:  req.Quantity,
		}
		if err := h.DB.Create(&item).Error; err != nil {
			Error(c, http.StatusInternalServerError, "failed to add cart item")
			return
		}
	default:
		Error(c, http.StatusInternalServerError, "failed to query cart item")
		return
	}

	item.Product = product
	OK(c, gin.H{"cartItem": h.toCartItemResponse(c, item)})
}

func (h OrderHandler) UpdateCartItem(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	var req updateCartItemRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}
	if req.Quantity < 1 {
		Error(c, http.StatusBadRequest, "quantity must be greater than 0")
		return
	}

	item, ok := h.findCartItem(c, userID, c.Param("id"))
	if !ok {
		return
	}

	item.Quantity = req.Quantity
	if err := h.DB.Save(&item).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to update cart item")
		return
	}

	OK(c, gin.H{"cartItem": h.toCartItemResponse(c, item)})
}

func (h OrderHandler) DeleteCartItem(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	item, ok := h.findCartItem(c, userID, c.Param("id"))
	if !ok {
		return
	}
	if err := h.DB.Delete(&item).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to delete cart item")
		return
	}

	OK(c, gin.H{"deleted": true})
}

func (h OrderHandler) CreateOrder(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	var req createOrderRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		Error(c, http.StatusBadRequest, "invalid request body")
		return
	}

	cartItems, ok := h.findCheckoutCartItems(c, userID, req.CartItemIDs)
	if !ok {
		return
	}
	if len(cartItems) == 0 {
		Error(c, http.StatusBadRequest, "cart is empty")
		return
	}

	for _, item := range cartItems {
		if item.Product.Status != models.ProductStatusPublished {
			Error(c, http.StatusBadRequest, "product is unavailable")
			return
		}
	}

	orderID := uuid.NewString()
	orderItems := buildOrderItems(orderID, cartItems)
	totalAmount, _ := summarizeOrderItems(orderItems)
	order := models.TravelOrder{
		ID:            orderID,
		OrderNo:       buildOrderNumber(time.Now(), userID),
		UserID:        userID,
		Status:        models.OrderStatusPendingPayment,
		PaymentStatus: models.PaymentStatusUnpaid,
		PaymentMethod: h.defaultPaymentMethod(),
		TotalAmount:   totalAmount,
	}

	if err := h.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&order).Error; err != nil {
			return err
		}
		if err := tx.Create(&orderItems).Error; err != nil {
			return err
		}
		ids := make([]string, 0, len(cartItems))
		for _, item := range cartItems {
			ids = append(ids, item.ID)
		}
		return tx.Delete(&models.TravelCartItem{}, "id IN ?", ids).Error
	}); err != nil {
		Error(c, http.StatusInternalServerError, "failed to create order")
		return
	}

	order.Items = orderItems
	OK(c, gin.H{"order": h.toOrderResponse(c, order)})
}

func (h OrderHandler) MockPayOrder(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	var order models.TravelOrder
	if err := h.DB.Preload("Items").Preload("User").Where("id = ? AND user_id = ?", c.Param("id"), userID).First(&order).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "order not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query order")
		return
	}

	if order.PaymentStatus == models.PaymentStatusPaid {
		if err := h.syncPaidOrderStateForUser(userID, &order); err != nil {
			Error(c, http.StatusInternalServerError, "failed to load paid order")
			return
		}
		OK(c, gin.H{"order": h.toOrderResponse(c, order)})
		return
	}

	paidAt := time.Now()
	if err := h.DB.Transaction(func(tx *gorm.DB) error {
		return h.completeOrderPayment(tx, &order, models.PaymentMethodMockWechat, "", paidAt)
	}); err != nil {
		Error(c, http.StatusInternalServerError, "failed to complete mock payment")
		return
	}

	OK(c, gin.H{"order": h.toOrderResponse(c, order)})
}

func (h OrderHandler) UserListOrders(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	page, pageSize := pagination(c)
	status := strings.TrimSpace(c.Query("status"))

	var total int64
	query := h.DB.Model(&models.TravelOrder{}).Where("user_id = ?", userID)
	if status != "" {
		if !models.ValidOrderStatus(status) {
			Error(c, http.StatusBadRequest, "invalid order status")
			return
		}
		query = query.Where("status IN ?", models.OrderStatusQueryValues(status))
	}
	if err := query.Count(&total).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to count orders")
		return
	}

	var orders []models.TravelOrder
	if err := query.Preload("Items").Preload("User").
		Order("created_at DESC").
		Offset((page - 1) * pageSize).
		Limit(pageSize).
		Find(&orders).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to list orders")
		return
	}

	OK(c, gin.H{"orderList": h.toOrderResponses(c, orders), "total": total})
}

func (h OrderHandler) UserOrderDetail(c *gin.Context) {
	userID, ok := currentUserID(c)
	if !ok {
		return
	}

	order, ok := h.findOrderForUser(c, userID, c.Param("id"))
	if !ok {
		return
	}

	OK(c, gin.H{"order": h.toOrderResponse(c, order)})
}

func (h OrderHandler) AdminListOrders(c *gin.Context) {
	page, pageSize := pagination(c)
	status := strings.TrimSpace(c.Query("status"))
	keyword := strings.TrimSpace(c.Query("keyword"))

	var total int64
	query := h.DB.Model(&models.TravelOrder{})
	if status != "" {
		if !models.ValidOrderStatus(status) {
			Error(c, http.StatusBadRequest, "invalid order status")
			return
		}
		query = query.Where("travel_orders.status IN ?", models.OrderStatusQueryValues(status))
	}
	if keyword != "" {
		pattern := "%" + keyword + "%"
		query = query.
			Joins("LEFT JOIN users ON users.id = travel_orders.user_id").
			Where(
				"travel_orders.order_no ILIKE ? OR travel_orders.verification_code ILIKE ? OR users.username ILIKE ? OR users.nickname ILIKE ?",
				pattern,
				pattern,
				pattern,
				pattern,
			)
	}
	if err := query.Count(&total).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to count orders")
		return
	}

	var orders []models.TravelOrder
	if err := query.Preload("Items").Preload("User").
		Order("travel_orders.created_at DESC").
		Offset((page - 1) * pageSize).
		Limit(pageSize).
		Find(&orders).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to list orders")
		return
	}

	OK(c, gin.H{"orderList": h.toOrderResponses(c, orders), "total": total})
}

func (h OrderHandler) AdminOrderDetail(c *gin.Context) {
	var order models.TravelOrder
	if err := h.DB.Preload("Items").Preload("User").Where("id = ?", c.Param("id")).First(&order).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "order not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query order")
		return
	}

	OK(c, gin.H{"order": h.toOrderResponse(c, order)})
}

func (h OrderHandler) AdminVerifyOrder(c *gin.Context) {
	var req verifyOrderRequest
	if c.Request.ContentLength > 0 {
		if err := c.ShouldBindJSON(&req); err != nil {
			Error(c, http.StatusBadRequest, "invalid request body")
			return
		}
	}

	var order models.TravelOrder
	if err := h.DB.Preload("Items").Preload("User").Where("id = ?", c.Param("id")).First(&order).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			Error(c, http.StatusNotFound, "order not found")
			return
		}
		Error(c, http.StatusInternalServerError, "failed to query order")
		return
	}

	if order.PaymentStatus != models.PaymentStatusPaid {
		Error(c, http.StatusBadRequest, "order is not paid")
		return
	}

	expectedCode := h.orderVerificationCode(order)
	if code := strings.ToUpper(strings.TrimSpace(req.VerificationCode)); code != "" && code != strings.ToUpper(expectedCode) {
		Error(c, http.StatusBadRequest, "verification code does not match")
		return
	}

	if models.NormalizeOrderStatus(order.Status) == models.OrderStatusCompleted {
		order.Status = models.OrderStatusCompleted
		order.VerificationCode = expectedCode
		OK(c, gin.H{"order": h.toOrderResponse(c, order)})
		return
	}

	verifiedAt := time.Now()
	if err := h.DB.Model(&models.TravelOrder{}).
		Where("id = ?", order.ID).
		Updates(map[string]any{
			"status":            models.OrderStatusCompleted,
			"verification_code": expectedCode,
			"verified_at":       &verifiedAt,
		}).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to verify order")
		return
	}

	order.Status = models.OrderStatusCompleted
	order.VerificationCode = expectedCode
	order.VerifiedAt = &verifiedAt
	OK(c, gin.H{"order": h.toOrderResponse(c, order)})
}

func (h OrderHandler) findCartItem(c *gin.Context, userID string, itemID string) (models.TravelCartItem, bool) {
	var item models.TravelCartItem
	err := h.DB.Preload("Product").Where("id = ? AND user_id = ?", itemID, userID).First(&item).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		Error(c, http.StatusNotFound, "cart item not found")
		return item, false
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query cart item")
		return item, false
	}
	return item, true
}

func (h OrderHandler) findCheckoutCartItems(c *gin.Context, userID string, cartItemIDs []string) ([]models.TravelCartItem, bool) {
	query := h.DB.Preload("Product").Where("user_id = ?", userID)
	trimmedIDs := make([]string, 0, len(cartItemIDs))
	for _, id := range cartItemIDs {
		id = strings.TrimSpace(id)
		if id != "" {
			trimmedIDs = append(trimmedIDs, id)
		}
	}
	if len(trimmedIDs) > 0 {
		query = query.Where("id IN ?", trimmedIDs)
	}

	var cartItems []models.TravelCartItem
	if err := query.Order("created_at DESC").Find(&cartItems).Error; err != nil {
		Error(c, http.StatusInternalServerError, "failed to load checkout items")
		return nil, false
	}
	return cartItems, true
}

func (h OrderHandler) findOrderForUser(c *gin.Context, userID string, orderID string) (models.TravelOrder, bool) {
	var order models.TravelOrder
	err := h.DB.Preload("Items").Preload("User").Where("id = ? AND user_id = ?", orderID, userID).First(&order).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		Error(c, http.StatusNotFound, "order not found")
		return order, false
	}
	if err != nil {
		Error(c, http.StatusInternalServerError, "failed to query order")
		return order, false
	}
	return order, true
}

func (h OrderHandler) toCartPayload(c *gin.Context, cartItems []models.TravelCartItem) gin.H {
	responses := make([]cartItemResponse, 0, len(cartItems))
	totalQuantity := 0
	totalAmount := 0.0
	for _, item := range cartItems {
		response := h.toCartItemResponse(c, item)
		responses = append(responses, response)
		totalQuantity += response.Quantity
		totalAmount += response.SubtotalAmount
	}
	return gin.H{
		"cartItems":     responses,
		"totalQuantity": totalQuantity,
		"totalAmount":   totalAmount,
	}
}

func (h OrderHandler) toCartItemResponse(c *gin.Context, item models.TravelCartItem) cartItemResponse {
	subtotal := float64(item.Quantity) * item.Product.Price
	return cartItemResponse{
		ID:             item.ID,
		ProductID:      item.ProductID,
		Quantity:       item.Quantity,
		SubtotalAmount: subtotal,
		Product:        ProductHandler{Uploader: h.Uploader}.toProductResponse(c, item.Product),
		CreatedAt:      item.CreatedAt,
		UpdatedAt:      item.UpdatedAt,
	}
}

func (h OrderHandler) toOrderResponses(c *gin.Context, orders []models.TravelOrder) []orderResponse {
	responses := make([]orderResponse, 0, len(orders))
	for _, order := range orders {
		responses = append(responses, h.toOrderResponse(c, order))
	}
	return responses
}

func (h OrderHandler) toOrderResponse(c *gin.Context, order models.TravelOrder) orderResponse {
	order.Status = models.NormalizeOrderStatus(order.Status)
	order.VerificationCode = h.orderVerificationCode(order)

	items := make([]orderItemResponse, 0, len(order.Items))
	for _, item := range order.Items {
		items = append(items, orderItemResponse{
			TravelOrderItem:      item,
			ProductCoverImageURL: signImageKey(c, h.Uploader, item.ProductCoverImage),
		})
	}

	response := orderResponse{
		TravelOrder:   order,
		Items:         items,
		TotalQuantity: totalQuantityFromResponses(items),
	}
	response.User = orderUserResponse{
		ID:        order.User.ID,
		Username:  order.User.Username,
		Nickname:  order.User.Nickname,
		AvatarURL: signImageKey(c, h.Uploader, order.User.AvatarURL),
	}
	return response
}

func currentUserID(c *gin.Context) (string, bool) {
	subjectID, ok := c.Get(middleware.SubjectIDKey)
	if !ok {
		Error(c, http.StatusUnauthorized, "missing user identity")
		return "", false
	}
	userID, ok := subjectID.(string)
	if !ok || strings.TrimSpace(userID) == "" {
		Error(c, http.StatusUnauthorized, "invalid user identity")
		return "", false
	}
	return strings.TrimSpace(userID), true
}

func buildOrderItems(orderID string, cartItems []models.TravelCartItem) []models.TravelOrderItem {
	items := make([]models.TravelOrderItem, 0, len(cartItems))
	for _, cartItem := range cartItems {
		items = append(items, models.TravelOrderItem{
			ID:                uuid.NewString(),
			OrderID:           orderID,
			ProductID:         cartItem.ProductID,
			ProductTitle:      strings.TrimSpace(cartItem.Product.Title),
			ProductCoverImage: strings.TrimSpace(cartItem.Product.CoverImage),
			UnitPrice:         cartItem.Product.Price,
			Quantity:          cartItem.Quantity,
			SubtotalAmount:    cartItem.Product.Price * float64(cartItem.Quantity),
		})
	}
	return items
}

func summarizeOrderItems(items []models.TravelOrderItem) (float64, int) {
	totalAmount := 0.0
	totalQuantity := 0
	for _, item := range items {
		totalAmount += item.SubtotalAmount
		totalQuantity += item.Quantity
	}
	return totalAmount, totalQuantity
}

func totalQuantityFromResponses(items []orderItemResponse) int {
	total := 0
	for _, item := range items {
		total += item.Quantity
	}
	return total
}

func buildOrderNumber(now time.Time, userID string) string {
	suffix := strings.TrimSpace(userID)
	if len(suffix) > 4 {
		suffix = suffix[len(suffix)-4:]
	}
	if suffix == "" {
		suffix = "0000"
	}
	return fmt.Sprintf("TR%s%s", now.Format("20060102150405"), suffix)
}

func (h OrderHandler) defaultPaymentMethod() string {
	if h.WechatPay != nil && h.WechatPay.Configured() {
		return models.PaymentMethodWechatPay
	}
	return models.PaymentMethodMockWechat
}

func (h OrderHandler) orderVerificationCode(order models.TravelOrder) string {
	if order.PaymentStatus != models.PaymentStatusPaid {
		return ""
	}
	if code := strings.TrimSpace(order.VerificationCode); code != "" {
		return code
	}

	issuedAt := order.CreatedAt
	if order.PaidAt != nil && !order.PaidAt.IsZero() {
		issuedAt = *order.PaidAt
	}
	return models.BuildVerificationCode(order.ID, issuedAt)
}

func (h OrderHandler) syncPaidOrderStateForUser(userID string, order *models.TravelOrder) error {
	updates := map[string]any{}
	normalizedStatus := models.NormalizeOrderStatus(order.Status)
	if normalizedStatus != strings.TrimSpace(order.Status) {
		updates["status"] = normalizedStatus
	}

	verificationCode := h.orderVerificationCode(*order)
	if verificationCode != "" && strings.TrimSpace(order.VerificationCode) == "" {
		updates["verification_code"] = verificationCode
	}

	if len(updates) == 0 {
		order.Status = normalizedStatus
		order.VerificationCode = verificationCode
		return nil
	}

	if err := h.DB.Model(&models.TravelOrder{}).
		Where("id = ? AND user_id = ?", order.ID, userID).
		Updates(updates).Error; err != nil {
		return err
	}

	order.Status = normalizedStatus
	order.VerificationCode = verificationCode
	return nil
}
