package handlers

import (
	"testing"
	"travel-backend/internal/models"
)

func TestProductResponseCarriesDetailImageURLs(t *testing.T) {
	response := productResponse{
		TravelProduct: models.TravelProduct{
			ID:           "product",
			DetailImages: []string{"detail-1.jpg", "detail-2.jpg"},
		},
		DetailImageURLs: []string{"https://cdn.example.com/detail-1.jpg", "https://cdn.example.com/detail-2.jpg"},
	}

	if len(response.DetailImageURLs) != 2 {
		t.Fatalf("expected two detail image urls, got %d", len(response.DetailImageURLs))
	}
	if response.DetailImages[0] != "detail-1.jpg" {
		t.Fatalf("expected raw detail image key to remain on response")
	}
}
