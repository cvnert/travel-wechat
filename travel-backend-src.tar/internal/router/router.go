package router

import (
	"travel-backend/internal/auth"
	"travel-backend/internal/config"
	"travel-backend/internal/handlers"
	"travel-backend/internal/middleware"
	"travel-backend/internal/storage"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func New(db *gorm.DB, cfg config.Config, uploader storage.Uploader) *gin.Engine {
	r := gin.Default()

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	authHandler := handlers.AuthHandler{
		DB:               db,
		JWTSecret:        cfg.JWTSecret,
		JWTExpires:       cfg.JWTExpires,
		WechatMiniAppID:  cfg.WechatMiniAppID,
		WechatMiniSecret: cfg.WechatMiniSecret,
		Uploader:         uploader,
	}
	adminAuthHandler := handlers.AdminAuthHandler{
		DB:         db,
		JWTSecret:  cfg.JWTSecret,
		JWTExpires: cfg.JWTExpires,
	}
	productHandler := handlers.ProductHandler{DB: db, Uploader: uploader}
	homeBannerHandler := handlers.HomeBannerHandler{DB: db, Uploader: uploader}
	uploadHandler := handlers.UploadHandler{Uploader: uploader, Prefix: cfg.COSUploadPrefix, DB: db}
	orderHandler := handlers.OrderHandler{
		DB:       db,
		Uploader: uploader,
		WechatPay: &handlers.WechatPayService{
			AppID:                  cfg.WechatMiniAppID,
			MerchantID:             cfg.WechatPayMchID,
			PublicKeyID:            cfg.WechatPayPublicKeyID,
			PublicKeyPath:          cfg.WechatPayPublicKeyPath,
			APIv3Key:               cfg.WechatPayAPIv3Key,
			MerchantPrivateKeyPath: cfg.WechatPayMchPrivateKeyPath,
			MerchantCertSerialNo:   cfg.WechatPayMchCertSerialNo,
			NotifyURL:              cfg.WechatPayNotifyURL,
		},
	}

	r.Static("/uploads", cfg.UploadDir)

	api := r.Group("/api")
	{
		authRoutes := api.Group("/auth")
		{
			authRoutes.POST("/register", authHandler.Register)
			authRoutes.POST("/login", authHandler.Login)
			authRoutes.POST("/wechat-login", authHandler.WechatLogin)
			authRoutes.PUT("/wechat-profile", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), authHandler.UpdateWechatProfile)
			authRoutes.POST("/avatar", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), uploadHandler.UploadUserAvatar)
		}

		api.GET("/home", productHandler.PublicHome)
		api.GET("/products", productHandler.PublicList)
		api.GET("/products/:id", productHandler.PublicDetail)
		api.GET("/cart", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.ListCart)
		api.POST("/cart/items", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.AddCartItem)
		api.PATCH("/cart/items/:id", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.UpdateCartItem)
		api.DELETE("/cart/items/:id", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.DeleteCartItem)
		api.GET("/orders", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.UserListOrders)
		api.GET("/orders/:id", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.UserOrderDetail)
		api.POST("/orders", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.CreateOrder)
		api.POST("/orders/:id/pay", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.PayOrder)
		api.POST("/orders/:id/mock-pay", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectUser), orderHandler.MockPayOrder)
		api.POST("/payments/wechat/notify", orderHandler.WechatPayNotify)

		admin := api.Group("/admin")
		{
			admin.POST("/login", adminAuthHandler.Login)

			adminProducts := admin.Group("/products")
			adminProducts.Use(middleware.RequireAuth(cfg.JWTSecret, auth.SubjectAdmin))
			{
				adminProducts.GET("", productHandler.AdminList)
				adminProducts.GET("/:id", productHandler.AdminDetail)
				adminProducts.POST("", productHandler.Create)
				adminProducts.PUT("/:id", productHandler.Update)
				adminProducts.PATCH("/:id/status", productHandler.UpdateStatus)
			}

			adminBanners := admin.Group("/home-banners")
			adminBanners.Use(middleware.RequireAuth(cfg.JWTSecret, auth.SubjectAdmin))
			{
				adminBanners.GET("", homeBannerHandler.AdminList)
				adminBanners.GET("/:id", homeBannerHandler.AdminDetail)
				adminBanners.POST("", homeBannerHandler.Create)
				adminBanners.PUT("/:id", homeBannerHandler.Update)
				adminBanners.PATCH("/:id/status", homeBannerHandler.UpdateStatus)
			}

			adminOrders := admin.Group("/orders")
			adminOrders.Use(middleware.RequireAuth(cfg.JWTSecret, auth.SubjectAdmin))
			{
				adminOrders.GET("", orderHandler.AdminListOrders)
				adminOrders.GET("/:id", orderHandler.AdminOrderDetail)
				adminOrders.POST("/:id/verify", orderHandler.AdminVerifyOrder)
			}

			admin.POST("/uploads/images", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectAdmin), uploadHandler.UploadImage)
			admin.POST("/uploads/sign", middleware.RequireAuth(cfg.JWTSecret, auth.SubjectAdmin), uploadHandler.SignImages)
		}
	}

	return r
}
