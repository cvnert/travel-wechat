package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestFindDotEnvUpwardsFindsParentEnv(t *testing.T) {
	root := t.TempDir()
	nested := filepath.Join(root, "cmd", "server")
	if err := os.MkdirAll(nested, 0755); err != nil {
		t.Fatalf("mkdir nested: %v", err)
	}
	envPath := filepath.Join(root, ".env")
	if err := os.WriteFile(envPath, []byte("SERVER_ADDR=:9090\n"), 0644); err != nil {
		t.Fatalf("write env: %v", err)
	}

	got, ok := findDotEnvUpwards(nested)
	if !ok {
		t.Fatal("expected to find .env")
	}
	if got != envPath {
		t.Fatalf("expected %s, got %s", envPath, got)
	}
}

func TestOverloadDotEnvSupportsUTF8BOM(t *testing.T) {
	path := filepath.Join(t.TempDir(), ".env")
	content := append([]byte{0xEF, 0xBB, 0xBF}, []byte("DATABASE_URL=host=localhost user=postgres password=123456 dbname=travel\n")...)
	if err := os.WriteFile(path, content, 0644); err != nil {
		t.Fatalf("write env: %v", err)
	}

	t.Setenv("DATABASE_URL", "")
	if err := overloadDotEnv(path); err != nil {
		t.Fatalf("overloadDotEnv returned error: %v", err)
	}

	got := os.Getenv("DATABASE_URL")
	want := "host=localhost user=postgres password=123456 dbname=travel"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}
