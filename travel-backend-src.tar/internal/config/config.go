package config

import (
	"bytes"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	ServerAddr                 string
	DatabaseURL                string
	JWTSecret                  string
	JWTExpires                 time.Duration
	AdminSeedUser              string
	AdminSeedPass              string
	WechatMiniAppID            string
	WechatMiniSecret           string
	WechatPayMchID             string
	WechatPayPublicKeyID       string
	WechatPayPublicKeyPath     string
	WechatPayAPIv3Key          string
	WechatPayMchPrivateKeyPath string
	WechatPayMchCertSerialNo   string
	WechatPayNotifyURL         string
	UploadDriver               string
	UploadDir                  string
	COSSecretID                string
	COSSecretKey               string
	COSBucket                  string
	COSRegion                  string
	COSPublicBaseURL           string
	COSUploadPrefix            string
	COSSignedURLTTL            time.Duration
}

func Load() Config {
	loadDotEnv()

	expiresHours, err := strconv.Atoi(getenv("JWT_EXPIRES_HOURS", "168"))
	if err != nil || expiresHours <= 0 {
		expiresHours = 168
	}
	signedURLMinutes, err := strconv.Atoi(getenv("COS_SIGNED_URL_EXPIRES_MINUTES", "60"))
	if err != nil || signedURLMinutes <= 0 {
		signedURLMinutes = 60
	}

	return Config{
		ServerAddr:                 getenv("SERVER_ADDR", ":8080"),
		DatabaseURL:                getenv("DATABASE_URL", "host=localhost user=postgres password=postgres dbname=travel_mvp port=5432 sslmode=disable TimeZone=Asia/Shanghai"),
		JWTSecret:                  getenv("JWT_SECRET", "change-me"),
		JWTExpires:                 time.Duration(expiresHours) * time.Hour,
		AdminSeedUser:              getenv("ADMIN_SEED_USERNAME", "admin"),
		AdminSeedPass:              getenv("ADMIN_SEED_PASSWORD", "admin123456"),
		WechatMiniAppID:            getenv("WECHAT_MINI_APP_ID", ""),
		WechatMiniSecret:           getenv("WECHAT_MINI_APP_SECRET", ""),
		WechatPayMchID:             getenv("WECHAT_PAY_MCH_ID", ""),
		WechatPayPublicKeyID:       getenv("WECHAT_PAY_PUBLIC_KEY_ID", ""),
		WechatPayPublicKeyPath:     getenv("WECHAT_PAY_PUBLIC_KEY_PATH", ""),
		WechatPayAPIv3Key:          getenv("WECHAT_PAY_API_V3_KEY", ""),
		WechatPayMchPrivateKeyPath: getenv("WECHAT_PAY_MCH_PRIVATE_KEY_PATH", ""),
		WechatPayMchCertSerialNo:   getenv("WECHAT_PAY_MCH_CERT_SERIAL_NO", ""),
		WechatPayNotifyURL:         getenv("WECHAT_PAY_NOTIFY_URL", ""),
		UploadDriver:               getenv("UPLOAD_DRIVER", "local"),
		UploadDir:                  getenv("UPLOAD_DIR", "uploads"),
		COSSecretID:                getenv("COS_SECRET_ID", ""),
		COSSecretKey:               getenv("COS_SECRET_KEY", ""),
		COSBucket:                  getenv("COS_BUCKET", ""),
		COSRegion:                  getenv("COS_REGION", ""),
		COSPublicBaseURL:           getenv("COS_PUBLIC_BASE_URL", ""),
		COSUploadPrefix:            getenv("COS_UPLOAD_PREFIX", "uploads/"),
		COSSignedURLTTL:            time.Duration(signedURLMinutes) * time.Minute,
	}
}

func loadDotEnv() {
	if cwd, err := os.Getwd(); err == nil {
		if envPath, ok := findDotEnvUpwards(cwd); ok {
			_ = overloadDotEnv(envPath)
			return
		}
	}

	_, file, _, ok := runtime.Caller(0)
	if !ok {
		_ = godotenv.Load()
		return
	}
	if envPath, ok := projectDotEnvPathFromFile(file); ok {
		_ = overloadDotEnv(envPath)
	}
}

func overloadDotEnv(path string) error {
	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	content = bytes.TrimPrefix(content, []byte{0xEF, 0xBB, 0xBF})

	values, err := godotenv.UnmarshalBytes(content)
	if err != nil {
		return err
	}
	for key, value := range values {
		_ = os.Setenv(key, value)
	}
	return nil
}

func projectDotEnvPath() (string, bool) {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "", false
	}
	return projectDotEnvPathFromFile(file)
}

func projectDotEnvPathFromFile(file string) (string, bool) {
	projectRoot := filepath.Clean(filepath.Join(filepath.Dir(file), "..", ".."))
	envPath := filepath.Join(projectRoot, ".env")
	if _, err := os.Stat(envPath); err != nil {
		return envPath, false
	}
	return envPath, true
}

func findDotEnvUpwards(start string) (string, bool) {
	dir := filepath.Clean(start)
	for {
		envPath := filepath.Join(dir, ".env")
		if _, err := os.Stat(envPath); err == nil {
			return envPath, true
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			return "", false
		}
		dir = parent
	}
}

func getenv(key string, fallback string) string {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	return value
}
