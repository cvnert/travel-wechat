package storage

import (
	"context"
	"io"
	"os"
	"path/filepath"
)

type LocalUploader struct {
	UploadDir string
}

func (u LocalUploader) Upload(ctx context.Context, objectKey string, reader io.Reader) (UploadResult, error) {
	targetPath := filepath.Join(u.UploadDir, filepath.FromSlash(objectKey))
	if err := os.MkdirAll(filepath.Dir(targetPath), 0755); err != nil {
		return UploadResult{}, err
	}

	file, err := os.Create(targetPath)
	if err != nil {
		return UploadResult{}, err
	}
	defer file.Close()

	if _, err := io.Copy(file, reader); err != nil {
		return UploadResult{}, err
	}

	return UploadResult{Key: objectKey, URL: "/uploads/" + objectKey}, nil
}

func (u LocalUploader) SignedURL(ctx context.Context, objectKey string) (string, error) {
	return "/uploads/" + objectKey, nil
}

func (u LocalUploader) PublicURL(ctx context.Context, objectKey string) (string, error) {
	return "/uploads/" + objectKey, nil
}
