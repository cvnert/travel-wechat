package storage

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"path"
	"strings"
	"time"

	cos "github.com/mozillazg/go-cos"
)

type Uploader interface {
	Upload(ctx context.Context, objectKey string, reader io.Reader) (UploadResult, error)
	SignedURL(ctx context.Context, objectKey string) (string, error)
	PublicURL(ctx context.Context, objectKey string) (string, error)
}

type UploadResult struct {
	Key string
	URL string
}

type COSConfig struct {
	SecretID      string
	SecretKey     string
	Bucket        string
	Region        string
	PublicBaseURL string
	SignedURLTTL  time.Duration
}

type COSUploader struct {
	Client        *cos.Client
	Bucket        string
	Region        string
	PublicBaseURL string
	SecretID      string
	SecretKey     string
	SignedURLTTL  time.Duration
}

func NewCOSUploader(cfg COSConfig) (*COSUploader, error) {
	if cfg.SecretID == "" || cfg.SecretKey == "" || cfg.Bucket == "" || cfg.Region == "" {
		return nil, fmt.Errorf("cos config is incomplete")
	}

	bucketURL := fmt.Sprintf("https://%s.cos.%s.myqcloud.com", cfg.Bucket, cfg.Region)
	baseURL, err := cos.NewBaseURL(bucketURL)
	if err != nil {
		return nil, err
	}

	client := cos.NewClient(baseURL, &http.Client{
		Transport: &cos.AuthorizationTransport{
			SecretID:  cfg.SecretID,
			SecretKey: cfg.SecretKey,
			Expire:    cfg.SignedURLTTL,
		},
	})

	return &COSUploader{
		Client:        client,
		Bucket:        cfg.Bucket,
		Region:        cfg.Region,
		PublicBaseURL: cfg.PublicBaseURL,
		SecretID:      cfg.SecretID,
		SecretKey:     cfg.SecretKey,
		SignedURLTTL:  cfg.SignedURLTTL,
	}, nil
}

func (u *COSUploader) Upload(ctx context.Context, objectKey string, reader io.Reader) (UploadResult, error) {
	if _, err := u.Client.Object.Put(ctx, objectKey, reader, nil); err != nil {
		return UploadResult{}, err
	}
	url, err := u.SignedURL(ctx, objectKey)
	if err != nil {
		return UploadResult{}, err
	}
	return UploadResult{Key: objectKey, URL: url}, nil
}

func (u *COSUploader) SignedURL(ctx context.Context, objectKey string) (string, error) {
	ttl := u.SignedURLTTL
	if ttl <= 0 {
		ttl = time.Hour
	}
	signedURL, err := u.Client.Object.PresignedURL(ctx, http.MethodGet, objectKey, cos.Auth{
		SecretID:  u.SecretID,
		SecretKey: u.SecretKey,
		Expire:    ttl,
	}, nil)
	if err != nil {
		return "", err
	}
	return signedURL.String(), nil
}

func (u *COSUploader) PublicURL(ctx context.Context, objectKey string) (string, error) {
	return u.publicURL(objectKey), nil
}

func (u COSUploader) publicURL(objectKey string) string {
	baseURL := strings.TrimRight(u.PublicBaseURL, "/")
	if baseURL == "" {
		baseURL = fmt.Sprintf("https://%s.cos.%s.myqcloud.com", u.Bucket, u.Region)
	}
	return baseURL + "/" + strings.TrimLeft(path.Clean(objectKey), "/")
}
