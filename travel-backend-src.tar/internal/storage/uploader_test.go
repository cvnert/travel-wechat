package storage

import "testing"

func TestPublicURLUsesConfiguredBaseURL(t *testing.T) {
	uploader := COSUploader{PublicBaseURL: "https://example-1250000000.cos.ap-guangzhou.myqcloud.com/"}

	got := uploader.publicURL("travel/20260525/image.png")
	want := "https://example-1250000000.cos.ap-guangzhou.myqcloud.com/travel/20260525/image.png"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}

func TestPublicURLFallsBackToBucketEndpoint(t *testing.T) {
	uploader := COSUploader{
		Bucket: "example-1250000000",
		Region: "ap-guangzhou",
	}

	got := uploader.publicURL("travel/20260525/image.png")
	want := "https://example-1250000000.cos.ap-guangzhou.myqcloud.com/travel/20260525/image.png"
	if got != want {
		t.Fatalf("expected %s, got %s", want, got)
	}
}
