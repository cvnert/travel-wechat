package database

import (
	"strings"
	"travel-backend/internal/models"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func Open(dsn string) (*gorm.DB, error) {
	return gorm.Open(postgres.Open(dsn), &gorm.Config{})
}

func AutoMigrate(db *gorm.DB) error {
	if err := db.AutoMigrate(
		&models.User{},
		&models.AdminUser{},
		&models.TravelProduct{},
		&models.HomeBanner{},
		&models.TravelCartItem{},
		&models.TravelOrder{},
		&models.TravelOrderItem{},
	); err != nil {
		return err
	}

	return backfillLegacyOrders(db)
}

func backfillLegacyOrders(db *gorm.DB) error {
	var orders []models.TravelOrder
	if err := db.
		Where("status = ? OR (payment_status = ? AND COALESCE(verification_code, '') = '')", models.LegacyOrderStatusPaid, models.PaymentStatusPaid).
		Find(&orders).Error; err != nil {
		return err
	}

	for _, order := range orders {
		updates := map[string]any{}
		normalizedStatus := models.NormalizeOrderStatus(order.Status)
		if normalizedStatus != strings.TrimSpace(order.Status) {
			updates["status"] = normalizedStatus
		}
		if order.PaymentStatus == models.PaymentStatusPaid && strings.TrimSpace(order.VerificationCode) == "" {
			issuedAt := order.CreatedAt
			if order.PaidAt != nil && !order.PaidAt.IsZero() {
				issuedAt = *order.PaidAt
			}
			updates["verification_code"] = models.BuildVerificationCode(order.ID, issuedAt)
		}
		if len(updates) == 0 {
			continue
		}
		if err := db.Model(&models.TravelOrder{}).Where("id = ?", order.ID).Updates(updates).Error; err != nil {
			return err
		}
	}

	return nil
}
