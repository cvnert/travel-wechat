package models

import "time"

const (
	BannerStatusDraft     = "draft"
	BannerStatusPublished = "published"
	BannerStatusOffline   = "offline"
)

type HomeBanner struct {
	ID               string    `gorm:"type:uuid;primaryKey" json:"id"`
	Title            string    `gorm:"size:120;not null" json:"title"`
	Description      string    `gorm:"size:255" json:"description"`
	Image            string    `gorm:"size:500;not null" json:"image"`
	LinkedProductID  *string   `gorm:"type:uuid;index" json:"linkedProductId"`
	Tag              string    `gorm:"size:64" json:"tag"`
	SortOrder        int       `gorm:"not null;default:0" json:"sortOrder"`
	Status           string    `gorm:"size:20;not null;index" json:"status"`
	CreatedAt        time.Time `json:"createdAt"`
	UpdatedAt        time.Time `json:"updatedAt"`
}

func ValidBannerStatus(status string) bool {
	switch status {
	case BannerStatusDraft, BannerStatusPublished, BannerStatusOffline:
		return true
	default:
		return false
	}
}
