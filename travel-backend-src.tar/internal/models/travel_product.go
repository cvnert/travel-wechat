package models

import "time"

const (
	ProductStatusDraft     = "draft"
	ProductStatusPublished = "published"
	ProductStatusOffline   = "offline"
)

type TravelProduct struct {
	ID                   string    `gorm:"type:uuid;primaryKey" json:"id"`
	Title                string    `gorm:"size:120;not null" json:"title"`
	CoverImage           string    `gorm:"size:500;not null" json:"coverImage"`
	BannerImages         []string  `gorm:"serializer:json" json:"bannerImages"`
	DetailImages         []string  `gorm:"serializer:json" json:"detailImages"`
	ShortDescription     string    `gorm:"size:255" json:"shortDescription"`
	Price                float64   `gorm:"not null" json:"price"`
	SalesCount           int       `gorm:"not null;default:0" json:"salesCount"`
	Tag                  string    `gorm:"size:64" json:"tag"`
	Summary              string    `gorm:"type:text" json:"summary"`
	Itinerary            string    `gorm:"type:text;not null" json:"itinerary"`
	FeeDescription       string    `gorm:"type:text;not null" json:"feeDescription"`
	TravelNotice         string    `gorm:"type:text;not null" json:"travelNotice"`
	RefundPolicy         string    `gorm:"type:text" json:"refundPolicy"`
	CustomerServicePhone string    `gorm:"size:32" json:"customerServicePhone"`
	SortOrder            int       `gorm:"not null;default:0" json:"sortOrder"`
	Status               string    `gorm:"size:20;not null;index" json:"status"`
	CreatedAt            time.Time `json:"createdAt"`
	UpdatedAt            time.Time `json:"updatedAt"`
}

func ValidProductStatus(status string) bool {
	switch status {
	case ProductStatusDraft, ProductStatusPublished, ProductStatusOffline:
		return true
	default:
		return false
	}
}
