package models

import (
	"testing"
	"time"
)

func TestValidOrderStatusSupportsTravelLifecycleAndLegacyAlias(t *testing.T) {
	for _, status := range []string{
		OrderStatusPendingPayment,
		"pending_travel",
		"completed",
		"paid",
	} {
		if !ValidOrderStatus(status) {
			t.Fatalf("expected %s to be valid", status)
		}
	}

	if ValidOrderStatus("cancelled") {
		t.Fatal("expected cancelled to be invalid")
	}
}

func TestNormalizeOrderStatusMapsLegacyPaidToPendingTravel(t *testing.T) {
	if got := NormalizeOrderStatus("paid"); got != "pending_travel" {
		t.Fatalf("expected paid to normalize to pending_travel, got %s", got)
	}

	if got := NormalizeOrderStatus(OrderStatusCompleted); got != OrderStatusCompleted {
		t.Fatalf("expected completed to stay completed, got %s", got)
	}
}

func TestOrderStatusQueryValuesIncludesLegacyPaidRows(t *testing.T) {
	values := OrderStatusQueryValues("pending_travel")
	if len(values) != 2 {
		t.Fatalf("expected 2 query values, got %d", len(values))
	}
	if values[0] != "pending_travel" || values[1] != "paid" {
		t.Fatalf("unexpected query values: %#v", values)
	}
}

func TestBuildVerificationCodeUsesDateAndOrderIDSuffix(t *testing.T) {
	issuedAt := time.Date(2026, 5, 30, 9, 8, 7, 0, time.UTC)

	got := BuildVerificationCode("7d50c9de-c1a0-4c66-8d49-8a50b5d5d1b7", issuedAt)

	if got != "HX260530D5D1B7" {
		t.Fatalf("unexpected verification code: %s", got)
	}
}
