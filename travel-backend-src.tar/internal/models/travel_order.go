package models

import (
	"strings"
	"time"
)

const (
	OrderStatusPendingPayment = "pending_payment"
	OrderStatusPendingTravel  = "pending_travel"
	OrderStatusCompleted      = "completed"
	LegacyOrderStatusPaid     = "paid"

	PaymentStatusUnpaid = "unpaid"
	PaymentStatusPaid   = "paid"

	PaymentMethodWechatPay  = "wechat_pay"
	PaymentMethodMockWechat = "mock_wechat"
)

type TravelOrder struct {
	ID                  string            `gorm:"type:uuid;primaryKey" json:"id"`
	OrderNo             string            `gorm:"size:32;uniqueIndex;not null" json:"orderNo"`
	UserID              string            `gorm:"type:uuid;not null;index" json:"userId"`
	Status              string            `gorm:"size:32;not null;index" json:"status"`
	PaymentStatus       string            `gorm:"size:32;not null;index" json:"paymentStatus"`
	PaymentMethod       string            `gorm:"size:32;not null" json:"paymentMethod"`
	WechatTransactionID string            `gorm:"size:64;index" json:"wechatTransactionId"`
	TotalAmount         float64           `gorm:"not null" json:"totalAmount"`
	VerificationCode    string            `gorm:"size:32;index" json:"verificationCode"`
	PaidAt              *time.Time        `json:"paidAt"`
	VerifiedAt          *time.Time        `json:"verifiedAt"`
	User                User              `gorm:"foreignKey:UserID;references:ID" json:"-"`
	Items               []TravelOrderItem `gorm:"foreignKey:OrderID;references:ID" json:"-"`
	CreatedAt           time.Time         `json:"createdAt"`
	UpdatedAt           time.Time         `json:"updatedAt"`
}

type TravelOrderItem struct {
	ID                string    `gorm:"type:uuid;primaryKey" json:"id"`
	OrderID           string    `gorm:"type:uuid;not null;index" json:"orderId"`
	ProductID         string    `gorm:"type:uuid;not null;index" json:"productId"`
	ProductTitle      string    `gorm:"size:120;not null" json:"productTitle"`
	ProductCoverImage string    `gorm:"size:500" json:"productCoverImage"`
	UnitPrice         float64   `gorm:"not null" json:"unitPrice"`
	Quantity          int       `gorm:"not null" json:"quantity"`
	SubtotalAmount    float64   `gorm:"not null" json:"subtotalAmount"`
	CreatedAt         time.Time `json:"createdAt"`
	UpdatedAt         time.Time `json:"updatedAt"`
}

func ValidOrderStatus(status string) bool {
	switch NormalizeOrderStatus(status) {
	case OrderStatusPendingPayment, OrderStatusPendingTravel, OrderStatusCompleted:
		return true
	default:
		return false
	}
}

func NormalizeOrderStatus(status string) string {
	switch strings.TrimSpace(status) {
	case LegacyOrderStatusPaid:
		return OrderStatusPendingTravel
	default:
		return strings.TrimSpace(status)
	}
}

func OrderStatusQueryValues(status string) []string {
	switch NormalizeOrderStatus(status) {
	case OrderStatusPendingPayment:
		return []string{OrderStatusPendingPayment}
	case OrderStatusPendingTravel:
		return []string{OrderStatusPendingTravel, LegacyOrderStatusPaid}
	case OrderStatusCompleted:
		return []string{OrderStatusCompleted}
	default:
		return nil
	}
}

func BuildVerificationCode(orderID string, issuedAt time.Time) string {
	codeSuffix := strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(orderID), "-", ""))
	if len(codeSuffix) >= 6 {
		codeSuffix = codeSuffix[len(codeSuffix)-6:]
	}
	if codeSuffix == "" {
		codeSuffix = "000000"
	}
	for len(codeSuffix) < 6 {
		codeSuffix = "0" + codeSuffix
	}

	baseTime := issuedAt.UTC()
	if issuedAt.IsZero() {
		baseTime = time.Unix(0, 0).UTC()
	}

	return "HX" + baseTime.Format("060102") + codeSuffix
}
