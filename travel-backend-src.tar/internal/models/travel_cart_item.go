package models

import "time"

type TravelCartItem struct {
	ID        string        `gorm:"type:uuid;primaryKey" json:"id"`
	UserID    string        `gorm:"type:uuid;not null;index" json:"userId"`
	ProductID string        `gorm:"type:uuid;not null;index" json:"productId"`
	Quantity  int           `gorm:"not null;default:1" json:"quantity"`
	Product   TravelProduct `gorm:"foreignKey:ProductID;references:ID" json:"-"`
	CreatedAt time.Time     `json:"createdAt"`
	UpdatedAt time.Time     `json:"updatedAt"`
}
