package models

import "time"

type User struct {
	ID           string     `gorm:"type:uuid;primaryKey" json:"id"`
	Username     string     `gorm:"uniqueIndex;size:64" json:"username"`
	PasswordHash string     `gorm:"size:255" json:"-"`
	OpenID       string     `gorm:"uniqueIndex;size:128" json:"openid"`
	UnionID      string     `gorm:"size:128" json:"unionid"`
	SessionKey   string     `gorm:"size:255" json:"-"`
	Nickname     string     `gorm:"size:64" json:"nickname"`
	AvatarURL    string     `gorm:"size:500" json:"avatarUrl"`
	Gender       int        `gorm:"not null;default:0" json:"gender"`
	Country      string     `gorm:"size:64" json:"country"`
	Province     string     `gorm:"size:64" json:"province"`
	City         string     `gorm:"size:64" json:"city"`
	Language     string     `gorm:"size:32" json:"language"`
	CreatedAt    time.Time  `json:"createdAt"`
	UpdatedAt    time.Time  `json:"updatedAt"`
	LastLoginAt  *time.Time `json:"lastLoginAt"`
}
