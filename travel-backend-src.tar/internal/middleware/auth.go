package middleware

import (
	"net/http"
	"strings"
	"travel-backend/internal/auth"

	"github.com/gin-gonic/gin"
)

const SubjectIDKey = "subjectID"

func RequireAuth(secret string, subjectType auth.SubjectType) gin.HandlerFunc {
	return func(c *gin.Context) {
		header := c.GetHeader("Authorization")
		if header == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing authorization header"})
			return
		}

		parts := strings.SplitN(header, " ", 2)
		if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") || strings.TrimSpace(parts[1]) == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid authorization header"})
			return
		}

		claims, err := auth.ParseToken(parts[1], secret)
		if err != nil || claims.SubjectType != subjectType {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid token"})
			return
		}

		c.Set(SubjectIDKey, claims.SubjectID)
		c.Next()
	}
}
