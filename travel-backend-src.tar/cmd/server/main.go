package main

import (
	"errors"
	"log"
	"travel-backend/internal/auth"
	"travel-backend/internal/config"
	"travel-backend/internal/database"
	"travel-backend/internal/models"
	"travel-backend/internal/router"
	"travel-backend/internal/storage"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

func main() {
	cfg := config.Load()

	db, err := database.Open(cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("connect database: %v", err)
	}

	if err := database.AutoMigrate(db); err != nil {
		log.Fatalf("auto migrate: %v", err)
	}

	if err := seedAdmin(db, cfg.AdminSeedUser, cfg.AdminSeedPass); err != nil {
		log.Fatalf("seed admin: %v", err)
	}

	uploader, err := buildUploader(cfg)
	if err != nil {
		log.Fatalf("build uploader: %v", err)
	}

	r := router.New(db, cfg, uploader)
	if err := r.Run(cfg.ServerAddr); err != nil {
		log.Fatalf("run server: %v", err)
	}
}

func buildUploader(cfg config.Config) (storage.Uploader, error) {
	if cfg.UploadDriver == "cos" {
		return storage.NewCOSUploader(storage.COSConfig{
			SecretID:      cfg.COSSecretID,
			SecretKey:     cfg.COSSecretKey,
			Bucket:        cfg.COSBucket,
			Region:        cfg.COSRegion,
			PublicBaseURL: cfg.COSPublicBaseURL,
			SignedURLTTL:  cfg.COSSignedURLTTL,
		})
	}

	return storage.LocalUploader{UploadDir: cfg.UploadDir}, nil
}

func seedAdmin(db *gorm.DB, username string, password string) error {
	if username == "" || password == "" {
		return nil
	}

	var admin models.AdminUser
	err := db.Where("username = ?", username).First(&admin).Error
	if err == nil {
		return nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}

	hash, err := auth.HashPassword(password)
	if err != nil {
		return err
	}

	return db.Create(&models.AdminUser{
		ID:           uuid.NewString(),
		Username:     username,
		PasswordHash: hash,
	}).Error
}
