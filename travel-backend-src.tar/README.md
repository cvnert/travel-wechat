# Travel Backend

Gin + GORM + PostgreSQL backend for the travel mini-program MVP.

## Setup

1. Copy `.env.example` to `.env`.
2. Update `DATABASE_URL` and `JWT_SECRET`.
3. Create the PostgreSQL database.
4. Run:

```powershell
go run ./cmd/server
```

The server runs on `SERVER_ADDR`, default `:8080`.

## APIs

- `GET /health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/wechat-login`
- `PUT /api/auth/wechat-profile`
- `POST /api/auth/avatar`
- `GET /api/home`
- `GET /api/products`
- `GET /api/products/:id`
- `GET /api/cart`
- `POST /api/cart/items`
- `PATCH /api/cart/items/:id`
- `DELETE /api/cart/items/:id`
- `GET /api/orders`
- `GET /api/orders/:id`
- `POST /api/orders`
- `POST /api/orders/:id/pay`
- `POST /api/orders/:id/mock-pay`
- `POST /api/payments/wechat/notify`
- `POST /api/admin/login`
- `GET /api/admin/products`
- `GET /api/admin/products/:id`
- `POST /api/admin/products`
- `PUT /api/admin/products/:id`
- `PATCH /api/admin/products/:id/status`
- `GET /api/admin/home-banners`
- `GET /api/admin/home-banners/:id`
- `POST /api/admin/home-banners`
- `PUT /api/admin/home-banners/:id`
- `PATCH /api/admin/home-banners/:id/status`
- `GET /api/admin/orders`
- `GET /api/admin/orders/:id`
- `POST /api/admin/orders/:id/verify`
- `POST /api/admin/uploads/images`
- `POST /api/admin/uploads/sign`

Admin product APIs require `Authorization: Bearer <token>` from `/api/admin/login`.
Admin upload API accepts multipart form field `file` and returns `{ "key": "travel/...", "url": "temporary signed url" }`.

## Tencent Cloud COS Uploads

Set these values in `.env` to upload admin images to Tencent Cloud COS:

```env
UPLOAD_DRIVER=cos
COS_SECRET_ID=your-secret-id
COS_SECRET_KEY=your-secret-key
COS_BUCKET=example-1250000000
COS_REGION=ap-guangzhou
COS_PUBLIC_BASE_URL=https://example-1250000000.cos.ap-guangzhou.myqcloud.com
COS_UPLOAD_PREFIX=travel/
COS_SIGNED_URL_EXPIRES_MINUTES=60
```

Keep `UPLOAD_DRIVER=local` to use local disk uploads during development.
For private COS buckets, product image fields store object keys. APIs also return temporary signed URLs in `coverImageUrl` and `bannerImageUrls`.

The seed admin account comes from `.env`:

- `ADMIN_SEED_USERNAME`
- `ADMIN_SEED_PASSWORD`

## WeChat Mini Program Login

Set these values in backend `.env` for real WeChat login:

```env
WECHAT_MINI_APP_ID=your-mini-program-appid
WECHAT_MINI_APP_SECRET=your-mini-program-secret
```

The mini-program sends the `wx.login` code to `POST /api/auth/wechat-login`. The backend exchanges the code with WeChat `jscode2session` and issues the app JWT. After login, the mini-program can send authorized profile fields to `PUT /api/auth/wechat-profile`.

For `wx.chooseAvatar`, upload the selected avatar file to `POST /api/auth/avatar` with `Authorization: Bearer <token>` and multipart form field `file`. The backend stores the uploaded object key in the user record and returns a stable avatar URL in the response.

## WeChat Pay

To enable real mini-program payments, add these values to backend `.env`:

```env
WECHAT_PAY_MCH_ID=your-merchant-id
WECHAT_PAY_PUBLIC_KEY_ID=your-wechat-pay-public-key-id
WECHAT_PAY_PUBLIC_KEY_PATH=/etc/travel/wechatpay/pub_key.pem
WECHAT_PAY_API_V3_KEY=your-api-v3-key
WECHAT_PAY_MCH_PRIVATE_KEY_PATH=/etc/travel/wechatpay/apiclient_key.pem
WECHAT_PAY_MCH_CERT_SERIAL_NO=your-merchant-api-cert-serial-no
WECHAT_PAY_NOTIFY_URL=https://your-domain.com/api/payments/wechat/notify
```

`WECHAT_PAY_PUBLIC_KEY_PATH` should point to the downloaded `pub_key.pem` on the server. The backend signs JSAPI order requests with the merchant private key and certificate serial number, then verifies and decrypts WeChat Pay notifications with the APIv3 key and WeChat Pay public key.

## GitHub Actions Deployment

The workflow at `.github/workflows/deploy.yml` deploys the backend when `main` is pushed, or when it is manually triggered from GitHub Actions.

Add these repository secrets in GitHub:

- `DEPLOY_HOST`: server IP or host.
- `DEPLOY_USER`: SSH user, for example `root` or `deploy`.
- `DEPLOY_SSH_KEY`: private SSH key that can log in to the server.
- `DEPLOY_PORT`: SSH port. Optional, defaults to `22`.
- `DEPLOY_PATH`: deploy directory. Optional, defaults to `/opt/travel-backend`.
- `BACKEND_ENV`: production `.env` content.

Example `BACKEND_ENV`:

```env
SERVER_ADDR=:8080
DATABASE_URL=host=127.0.0.1 user=postgres password=your-password dbname=travel_mvp port=5432 sslmode=disable TimeZone=Asia/Shanghai
JWT_SECRET=replace-with-a-long-random-secret
JWT_EXPIRES_HOURS=168
ADMIN_SEED_USERNAME=admin
ADMIN_SEED_PASSWORD=replace-admin-password
WECHAT_MINI_APP_ID=your-mini-program-appid
WECHAT_MINI_APP_SECRET=your-mini-program-secret
WECHAT_PAY_MCH_ID=your-merchant-id
WECHAT_PAY_PUBLIC_KEY_ID=your-wechat-pay-public-key-id
WECHAT_PAY_PUBLIC_KEY_PATH=/etc/travel/wechatpay/pub_key.pem
WECHAT_PAY_API_V3_KEY=your-api-v3-key
WECHAT_PAY_MCH_PRIVATE_KEY_PATH=/etc/travel/wechatpay/apiclient_key.pem
WECHAT_PAY_MCH_CERT_SERIAL_NO=your-merchant-api-cert-serial-no
WECHAT_PAY_NOTIFY_URL=https://your-domain.com/api/payments/wechat/notify
UPLOAD_DRIVER=local
UPLOAD_DIR=uploads
```

The server must have PostgreSQL ready before deployment. The SSH user must be able to run `sudo systemctl` without an interactive password prompt, or use `root` as `DEPLOY_USER`.
